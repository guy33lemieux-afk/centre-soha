/* Centre Soha — le strict nécessaire : le menu, et l'estimateur. */
(function(){
  var menu=document.querySelector('.soha-menu');
  if(menu){
    var b=menu.querySelector('.soha-bascule');
    var ferme=function(){menu.removeAttribute('data-ouvert');b.setAttribute('aria-expanded','false');};
    b.addEventListener('click',function(){
      var ouvert=menu.getAttribute('data-ouvert')==='oui';
      if(ouvert){ferme();}else{menu.setAttribute('data-ouvert','oui');b.setAttribute('aria-expanded','true');}
    });
    document.addEventListener('keydown',function(e){if(e.key==='Escape')ferme();});
    document.addEventListener('click',function(e){if(!menu.contains(e.target))ferme();});
  }

  var racine=document.getElementById('sohaEstim');
  if(racine&&window.SOHA_ESTIM){
    var G=window.SOHA_ESTIM,RESA=window.SOHA_ESTIM_RESA||'#';
    var JOUR={sem:'Semaine',fds:'Fin de semaine'};
    var PLAGE={jour:'Journée',demi:'Demi-journée',soir:'Soirée'};
    var espace=racine.getAttribute('data-first'),jour='sem',plage='jour';
    var prix=racine.querySelector('#sePrice'),sel=racine.querySelector('#seSel'),cta=racine.querySelector('#seCta');
    function sync(){
      var e=G[espace],table=(jour==='fds')?e[3]:e[2],v=table[plage];
      prix.innerHTML=v.toLocaleString('fr-CA')+' $ <small>+tx</small>';
      sel.textContent=e[0]+' · '+JOUR[jour]+' · '+PLAGE[plage];
      cta.setAttribute('href',RESA+'?espace='+encodeURIComponent(espace)
        +'&jour='+encodeURIComponent(jour)+'&plage='+encodeURIComponent(plage)
        +'&tarif='+encodeURIComponent(v));
    }
    function groupe(id,poser){
      racine.querySelectorAll('#'+id+' button').forEach(function(b){
        b.addEventListener('click',function(){
          poser(b.getAttribute('data-k'));
          racine.querySelectorAll('#'+id+' button').forEach(function(x){x.classList.remove('on');});
          b.classList.add('on');sync();
        });
      });
    }
    groupe('seSpaces',function(v){espace=v;});
    groupe('seDay',function(v){jour=v;});
    groupe('seSlot',function(v){plage=v;});
    sync();
  }
})();
