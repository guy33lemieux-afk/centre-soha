(() => {
  // ../../../tmp/claude-0/-home-user-centre-soha/e9238a31-e6e0-596c-a8e9-203c161bd00f/scratchpad/x/build_crm/soha-crm/_travail/crm-source.jsx
  var React = window.wp.element;
  var { useState, useEffect, useMemo, useCallback } = window.wp.element;
  var STORE_KEY = "soha-crm:v1";
  var ECOLES = [
    { id: "soigner", label: "Soigner le vivant", color: "#19A7DB" },
    { id: "batir", label: "B\xE2tir le vivant", color: "#D29A4E" },
    { id: "cultiver", label: "Cultiver le vivant", color: "#5E8C5A" }
  ];
  var ecole = (id) => ECOLES.find((e) => e.id === id);
  var TYPES = [
    { id: "artisane", label: "Artisan\xB7e" },
    { id: "apprenante", label: "Apprenant\xB7e" },
    { id: "prospect", label: "Prospect" },
    { id: "partenaire", label: "Partenaire" }
  ];
  var typeLabel = (id) => (TYPES.find((t) => t.id === id) || {}).label || id;
  var STATUTS = ["Nouveau", "En discussion", "Actif", "R\xE9current", "Dormant"];
  var PAIEMENTS = [
    { id: "devis", label: "Devis", color: "#D29A4E" },
    { id: "confirme", label: "Confirm\xE9", color: "#19A7DB" },
    { id: "paye", label: "Pay\xE9", color: "#5E8C5A" }
  ];
  var paie = (id) => PAIEMENTS.find((p) => p.id === id) || PAIEMENTS[0];
  var ESPACES = ["Studio", "Espace S\xD6HA", "Salle 4", "Salles 1\xB72\xB73"];
  var RECURRENCES = ["Ponctuel", "R\xE9current", "Hebdomadaire", "Mensuel"];
  var uid = () => window.crypto && window.crypto.randomUUID && window.crypto.randomUUID() || String(Date.now()) + Math.random().toString(16).slice(2);
  var todayISO = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  var money = (n) => (Number(n) || 0).toLocaleString("fr-CA", { maximumFractionDigits: 0 }) + " $";
  var fmtDate = (iso) => {
    if (!iso) return "\u2014";
    const d = /* @__PURE__ */ new Date(iso + "T00:00:00");
    return d.toLocaleDateString("fr-CA", { day: "numeric", month: "short", year: "numeric" });
  };
  var monthLabel = () => (/* @__PURE__ */ new Date()).toLocaleDateString("fr-CA", { month: "long", year: "numeric" });
  var sameMonth = (iso) => {
    if (!iso) return false;
    const d = /* @__PURE__ */ new Date(iso + "T00:00:00"), n = /* @__PURE__ */ new Date();
    return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
  };
  var emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  var emptyInfo = () => ({ abonne: false, consentement: "", source: "", desabonne: false });
  var isAbonne = (c) => c.infolettre && c.infolettre.abonne && !c.infolettre.desabonne;
  var normalizeContact = (c) => ({
    etiquettes: [],
    interactions: [],
    note: "",
    ecole: "",
    courriel: "",
    telephone: "",
    ...c,
    infolettre: { ...emptyInfo(), ...c.infolettre || {} }
  });
  var seed = () => {
    const artisanes = [
      ["Dominique Mennessier", "A\xB7002 \xB7 co-associ\xE9e"],
      ["\xC8ve Morin", "A\xB7004"],
      ["Jeimy Oviedo", "A\xB7005"],
      ["Julie Habart", "A\xB7011"],
      ["Marjolaine Blouin", "A\xB7003"]
    ];
    const contacts = artisanes.map(
      ([nom, note]) => normalizeContact({
        id: uid(),
        nom,
        type: "artisane",
        statut: "Actif",
        note,
        ajoute: todayISO()
      })
    );
    return { contacts, reservations: [], ateliers: [], v: 2 };
  };
  function App() {
    const [data, setData] = useState(null);
    const [tab, setTab] = useState("dashboard");
    const [modal, setModal] = useState(null);
    const [openContact, setOpenContact] = useState(null);
    const [toast, setToast] = useState("");
    useEffect(() => {
      let alive = true;
      (async () => {
        let loaded = null;
        try {
          if (window.storage) {
            const r = await window.storage.get(STORE_KEY);
            if (r && r.value) loaded = JSON.parse(r.value);
          }
        } catch (e) {
          loaded = null;
        }
        if (!loaded) loaded = seed();
        loaded.contacts = (loaded.contacts || []).map(normalizeContact);
        loaded.reservations = loaded.reservations || [];
        loaded.ateliers = loaded.ateliers || [];
        try {
          if (window.storage) await window.storage.set(STORE_KEY, JSON.stringify(loaded));
        } catch (e) {
        }
        if (alive) setData(loaded);
      })();
      return () => {
        alive = false;
      };
    }, []);
    const persist = useCallback((next) => {
      setData(next);
      try {
        if (window.storage) window.storage.set(STORE_KEY, JSON.stringify(next));
      } catch (e) {
      }
    }, []);
    const flash = (m) => {
      setToast(m);
      setTimeout(() => setToast(""), 2400);
    };
    const upsert = (col, entity) => {
      const list = data[col].slice();
      const i = list.findIndex((x) => x.id === entity.id);
      if (i >= 0) list[i] = entity;
      else list.unshift(entity);
      persist({ ...data, [col]: list });
    };
    const remove = (col, id) => persist({ ...data, [col]: data[col].filter((x) => x.id !== id) });
    const addInteraction = (contactId, texte) => {
      const list = data.contacts.map(
        (c) => c.id === contactId ? { ...c, interactions: [{ id: uid(), date: todayISO(), texte }, ...c.interactions || []] } : c
      );
      persist({ ...data, contacts: list });
    };
    const setAbo = (contactId, abonne) => {
      const list = data.contacts.map((c) => {
        if (c.id !== contactId) return c;
        const info = { ...emptyInfo(), ...c.infolettre };
        if (abonne) {
          info.abonne = true;
          info.desabonne = false;
          if (!info.consentement) info.consentement = todayISO();
          if (!info.source) info.source = "manuel";
        } else {
          info.abonne = false;
          info.desabonne = true;
        }
        return { ...c, infolettre: info };
      });
      persist({ ...data, contacts: list });
    };
    const importAbonnes = (parsed) => {
      let ajoutes = 0, maj = 0;
      const byMail = {};
      data.contacts.forEach((c) => {
        if (c.courriel) byMail[c.courriel.toLowerCase()] = c.id;
      });
      let list = data.contacts.slice();
      const vus = {};
      parsed.forEach((p) => {
        if (vus[p.courriel]) return;
        vus[p.courriel] = true;
        const existingId = byMail[p.courriel];
        if (existingId) {
          list = list.map((c) => c.id === existingId ? { ...c, infolettre: { abonne: true, desabonne: false, consentement: c.infolettre.consentement || todayISO(), source: c.infolettre.source || "import" } } : c);
          maj++;
        } else {
          list.unshift(normalizeContact({
            id: uid(),
            nom: p.prenom || p.courriel,
            type: "apprenante",
            courriel: p.courriel,
            statut: "Nouveau",
            ajoute: todayISO(),
            infolettre: { abonne: true, desabonne: false, consentement: todayISO(), source: "import" }
          }));
          ajoutes++;
        }
      });
      persist({ ...data, contacts: list });
      return { ajoutes, maj };
    };
    if (!data) return /* @__PURE__ */ React.createElement(Loading, null);
    const contactById = (id) => data.contacts.find((c) => c.id === id);
    return /* @__PURE__ */ React.createElement("div", { className: "soha" }, /* @__PURE__ */ React.createElement(Style, null), /* @__PURE__ */ React.createElement("aside", { className: "rail" }, /* @__PURE__ */ React.createElement("div", { className: "brand" }, /* @__PURE__ */ React.createElement("span", { className: "brand-mark" }, "\u25E6"), /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("div", { className: "brand-name" }, "Centre Soha"), /* @__PURE__ */ React.createElement("div", { className: "brand-sub" }, "961 Rachel Est"))), /* @__PURE__ */ React.createElement("nav", null, [
      ["dashboard", "Tableau de bord"],
      ["repertoire", "R\xE9pertoire"],
      ["infolettre", "Infolettre"],
      ["location", "Location"],
      ["ateliers", "Ateliers"]
    ].map(([id, label]) => /* @__PURE__ */ React.createElement("button", { key: id, className: "navlink" + (tab === id ? " on" : ""), onClick: () => {
      setTab(id);
      setOpenContact(null);
    } }, label))), /* @__PURE__ */ React.createElement("div", { className: "rail-foot" }, /* @__PURE__ */ React.createElement(ExportMenu, { data, onReset: () => {
      persist(seed());
      flash("R\xE9pertoire r\xE9initialis\xE9.");
    } }), /* @__PURE__ */ React.createElement("div", { className: "rail-note" }, "Donn\xE9es gard\xE9es dans la base du site, sauvegard\xE9es avec elle."))), /* @__PURE__ */ React.createElement("main", { className: "main" }, tab === "dashboard" && /* @__PURE__ */ React.createElement(
      Dashboard,
      {
        data,
        contactById,
        openContact: (id) => {
          setTab("repertoire");
          setOpenContact(id);
        }
      }
    ), tab === "repertoire" && /* @__PURE__ */ React.createElement(
      Repertoire,
      {
        data,
        openId: openContact,
        setOpen: setOpenContact,
        onNew: () => setModal({ kind: "contact", mode: "add", entity: null }),
        onEdit: (c) => setModal({ kind: "contact", mode: "edit", entity: c }),
        onDelete: (id) => {
          remove("contacts", id);
          setOpenContact(null);
          flash("Contact retir\xE9.");
        },
        onInteraction: addInteraction,
        setAbo,
        reservations: data.reservations
      }
    ), tab === "infolettre" && /* @__PURE__ */ React.createElement(
      Infolettre,
      {
        data,
        onImport: importAbonnes,
        setAbo,
        openContact: (id) => {
          setTab("repertoire");
          setOpenContact(id);
        },
        flash
      }
    ), tab === "location" && /* @__PURE__ */ React.createElement(
      Location,
      {
        data,
        contactById,
        onNew: () => setModal({ kind: "reservation", mode: "add", entity: null }),
        onEdit: (r) => setModal({ kind: "reservation", mode: "edit", entity: r }),
        onDelete: (id) => {
          remove("reservations", id);
          flash("R\xE9servation retir\xE9e.");
        }
      }
    ), tab === "ateliers" && /* @__PURE__ */ React.createElement(
      Ateliers,
      {
        data,
        contactById,
        onNew: () => setModal({ kind: "atelier", mode: "add", entity: null }),
        onEdit: (a) => setModal({ kind: "atelier", mode: "edit", entity: a }),
        onDelete: (id) => {
          remove("ateliers", id);
          flash("Atelier retir\xE9.");
        }
      }
    )), modal && modal.kind === "contact" && /* @__PURE__ */ React.createElement(
      ContactForm,
      {
        modal,
        onClose: () => setModal(null),
        onSave: (c) => {
          upsert("contacts", c);
          setModal(null);
          flash("Contact enregistr\xE9.");
        }
      }
    ), modal && modal.kind === "reservation" && /* @__PURE__ */ React.createElement(
      ReservationForm,
      {
        modal,
        contacts: data.contacts,
        onClose: () => setModal(null),
        onSave: (r) => {
          upsert("reservations", r);
          setModal(null);
          flash("R\xE9servation enregistr\xE9e.");
        }
      }
    ), modal && modal.kind === "atelier" && /* @__PURE__ */ React.createElement(
      AtelierForm,
      {
        modal,
        contacts: data.contacts,
        onClose: () => setModal(null),
        onSave: (a) => {
          upsert("ateliers", a);
          setModal(null);
          flash("Atelier enregistr\xE9.");
        }
      }
    ), toast && /* @__PURE__ */ React.createElement("div", { className: "toast" }, toast));
  }
  function Dashboard({ data, contactById, openContact }) {
    const paye = data.reservations.filter((r) => r.paiement === "paye" && sameMonth(r.date)).reduce((s, r) => s + (Number(r.prix) || 0), 0);
    const aVenir = data.reservations.filter((r) => r.paiement === "confirme" && sameMonth(r.date)).reduce((s, r) => s + (Number(r.prix) || 0), 0);
    const parType = TYPES.map((t) => ({ ...t, n: data.contacts.filter((c) => c.type === t.id).length }));
    const nbAbonnes = data.contacts.filter(isAbonne).length;
    const prochaines = data.reservations.filter((r) => r.date >= todayISO()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 5);
    const prochainsAteliers = data.ateliers.filter((a) => a.date >= todayISO()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
    const aRelancer = data.contacts.filter((c) => c.type === "prospect" || c.statut === "Nouveau" || c.statut === "En discussion" || c.statut === "Dormant").slice(0, 6);
    return /* @__PURE__ */ React.createElement("div", { className: "page" }, /* @__PURE__ */ React.createElement("header", { className: "page-head" }, /* @__PURE__ */ React.createElement("span", { className: "kicker" }, "Centre Soha \xB7 ", monthLabel()), /* @__PURE__ */ React.createElement("h1", null, "O\xF9 on en est.")), /* @__PURE__ */ React.createElement("section", { className: "grid" }, /* @__PURE__ */ React.createElement("div", { className: "card hero-card" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Revenu location \xB7 ce mois"), /* @__PURE__ */ React.createElement("div", { className: "hero-num" }, money(paye)), /* @__PURE__ */ React.createElement("div", { className: "hero-sub" }, "encaiss\xE9 \u2014 ", /* @__PURE__ */ React.createElement("strong", null, money(aVenir)), " confirm\xE9 \xE0 venir"), /* @__PURE__ */ React.createElement("div", { className: "hero-tag" }, "Salles + studio \xB7 le socle r\xE9current")), /* @__PURE__ */ React.createElement("div", { className: "card" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "R\xE9pertoire"), /* @__PURE__ */ React.createElement("div", { className: "stat" }, data.contacts.length), /* @__PURE__ */ React.createElement("div", { className: "type-list" }, parType.map((t) => /* @__PURE__ */ React.createElement("div", { key: t.id, className: "type-row" }, /* @__PURE__ */ React.createElement("span", { className: "type-name" }, t.label), /* @__PURE__ */ React.createElement("span", { className: "mono" }, t.n))), /* @__PURE__ */ React.createElement("div", { className: "type-row" }, /* @__PURE__ */ React.createElement("span", { className: "type-name" }, "Abonn\xE9s infolettre"), /* @__PURE__ */ React.createElement("span", { className: "mono", style: { color: "var(--soigner)" } }, nbAbonnes)))), /* @__PURE__ */ React.createElement("div", { className: "card" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "\xC0 relancer"), aRelancer.length === 0 ? /* @__PURE__ */ React.createElement(Empty, { small: true }, "Personne en attente. Beau travail.") : /* @__PURE__ */ React.createElement("ul", { className: "mini-list" }, aRelancer.map((c) => /* @__PURE__ */ React.createElement("li", { key: c.id }, /* @__PURE__ */ React.createElement("button", { className: "linkish", onClick: () => openContact(c.id) }, c.nom), /* @__PURE__ */ React.createElement("span", { className: "mono tiny" }, c.statut)))))), /* @__PURE__ */ React.createElement("section", { className: "two-col" }, /* @__PURE__ */ React.createElement("div", { className: "card" }, /* @__PURE__ */ React.createElement("div", { className: "card-head" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Prochaines r\xE9servations")), prochaines.length === 0 ? /* @__PURE__ */ React.createElement(Empty, null, "Rien de r\xE9serv\xE9. Ouvre l'agenda des salles \u2014 c'est l\xE0 que le revenu se joue.") : /* @__PURE__ */ React.createElement("table", { className: "tbl" }, /* @__PURE__ */ React.createElement("tbody", null, prochaines.map((r) => {
      const c = contactById(r.contactId);
      const p = paie(r.paiement);
      return /* @__PURE__ */ React.createElement("tr", { key: r.id }, /* @__PURE__ */ React.createElement("td", { className: "mono nowrap" }, fmtDate(r.date)), /* @__PURE__ */ React.createElement("td", null, r.espace), /* @__PURE__ */ React.createElement("td", { className: "dim" }, c ? c.nom : "\u2014"), /* @__PURE__ */ React.createElement("td", { className: "mono nowrap" }, money(r.prix)), /* @__PURE__ */ React.createElement("td", null, /* @__PURE__ */ React.createElement(Badge, { color: p.color, label: p.label })));
    })))), /* @__PURE__ */ React.createElement("div", { className: "card" }, /* @__PURE__ */ React.createElement("div", { className: "card-head" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Prochains ateliers")), prochainsAteliers.length === 0 ? /* @__PURE__ */ React.createElement(Empty, null, "Aucun atelier planifi\xE9.") : /* @__PURE__ */ React.createElement("ul", { className: "atelier-mini" }, prochainsAteliers.map((a) => {
      const e = ecole(a.ecole);
      const art = contactById(a.artisanId);
      return /* @__PURE__ */ React.createElement("li", { key: a.id }, /* @__PURE__ */ React.createElement("div", { className: "am-top" }, e && /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: e.color } }), /* @__PURE__ */ React.createElement("span", { className: "am-title" }, a.titre)), /* @__PURE__ */ React.createElement("div", { className: "am-meta mono tiny" }, fmtDate(a.date), " \xB7 ", art ? art.nom : "artisan\xB7e \xE0 confirmer"));
    })))));
  }
  function Infolettre({ data, onImport, setAbo, openContact, flash }) {
    const [raw, setRaw] = useState("");
    const abonnes = data.contacts.filter(isAbonne).sort((a, b) => a.nom.localeCompare(b.nom));
    const parse = (text) => {
      const out = [];
      text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).forEach((line) => {
        const cells = line.split(/[;,\t]/).map((c) => c.trim().replace(/^"|"$/g, ""));
        const email = cells.find((c) => emailRe.test(c));
        if (!email) return;
        const prenom = cells.find((c) => c && c !== email && !/@/.test(c)) || "";
        out.push({ courriel: email.toLowerCase(), prenom });
      });
      return out;
    };
    const runImport = () => {
      const parsed = parse(raw);
      if (parsed.length === 0) {
        flash("Aucun courriel valide d\xE9tect\xE9.");
        return;
      }
      const { ajoutes, maj } = onImport(parsed);
      setRaw("");
      flash(`${ajoutes} ajout\xE9\xB7es \xB7 ${maj} mis \xE0 jour.`);
    };
    const exportListe = () => {
      const head = ["courriel", "prenom"];
      const lines = [head.join(",")].concat(
        abonnes.map((c) => [c.courriel, c.nom !== c.courriel ? c.nom : ""].map((v) => '"' + String(v || "").replace(/"/g, '""') + '"').join(","))
      );
      const blob = new Blob([lines.join("\n")], { type: "text/csv" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "soha_liste_infolettre_" + todayISO().replace(/-/g, "") + ".csv";
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    };
    return /* @__PURE__ */ React.createElement("div", { className: "page" }, /* @__PURE__ */ React.createElement("header", { className: "page-head" }, /* @__PURE__ */ React.createElement("span", { className: "kicker" }, "Infolettre"), /* @__PURE__ */ React.createElement("h1", null, "Ceux qui veulent des nouvelles.")), /* @__PURE__ */ React.createElement("div", { className: "info-grid" }, /* @__PURE__ */ React.createElement("div", { className: "card" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Abonn\xE9s actifs"), /* @__PURE__ */ React.createElement("div", { className: "stat", style: { color: "var(--soigner)" } }, abonnes.length), /* @__PURE__ */ React.createElement("p", { className: "dim tiny", style: { marginTop: 4 } }, "Consentement dat\xE9, source gard\xE9e. Chacun peut se d\xE9sabonner d'un clic."), abonnes.length > 0 && /* @__PURE__ */ React.createElement("button", { className: "btn", style: { marginTop: 14 }, onClick: exportListe }, "Exporter la liste d'envoi (CSV)")), /* @__PURE__ */ React.createElement("div", { className: "card import-card" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Importer des abonn\xE9s"), /* @__PURE__ */ React.createElement("p", { className: "dim tiny", style: { margin: "6px 0 10px" } }, "Colle l'export de Cyberimpact (ou une colonne de courriels). Un courriel par ligne, pr\xE9nom si tu l'as. Les contacts existants sont reconnus, les nouveaux sont cr\xE9\xE9s en apprenant\xB7e."), /* @__PURE__ */ React.createElement("textarea", { className: "import-box", rows: 5, placeholder: "prenom, courriel\n\xC9lo\xEFse, eloise@exemple.ca\njean@exemple.ca", value: raw, onChange: (e) => setRaw(e.target.value) }), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", style: { marginTop: 10 }, onClick: runImport }, "Importer"))), abonnes.length === 0 ? /* @__PURE__ */ React.createElement(Empty, null, "Aucun abonn\xE9 pour l'instant. Mets le formulaire en ligne, laisse Cyberimpact recueillir, puis rapatrie la liste ici.") : /* @__PURE__ */ React.createElement("table", { className: "tbl full" }, /* @__PURE__ */ React.createElement("thead", null, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", null, "Nom"), /* @__PURE__ */ React.createElement("th", null, "Courriel"), /* @__PURE__ */ React.createElement("th", null, "Consentement"), /* @__PURE__ */ React.createElement("th", null, "Source"), /* @__PURE__ */ React.createElement("th", null))), /* @__PURE__ */ React.createElement("tbody", null, abonnes.map((c) => /* @__PURE__ */ React.createElement("tr", { key: c.id }, /* @__PURE__ */ React.createElement("td", { className: "strong" }, /* @__PURE__ */ React.createElement("button", { className: "linkish", onClick: () => openContact(c.id) }, c.nom)), /* @__PURE__ */ React.createElement("td", { className: "dim" }, c.courriel), /* @__PURE__ */ React.createElement("td", { className: "mono tiny" }, fmtDate(c.infolettre.consentement)), /* @__PURE__ */ React.createElement("td", { className: "tiny" }, c.infolettre.source || "\u2014"), /* @__PURE__ */ React.createElement("td", null, /* @__PURE__ */ React.createElement("button", { className: "x small", title: "D\xE9sabonner", onClick: () => {
      if (confirm("D\xE9sabonner " + c.nom + " ?")) {
        setAbo(c.id, false);
        flash("D\xE9sabonn\xE9\xB7e.");
      }
    } }, "\xD7")))))));
  }
  function Repertoire({ data, openId, setOpen, onNew, onEdit, onDelete, onInteraction, setAbo, reservations }) {
    const [q, setQ] = useState("");
    const [filtType, setFiltType] = useState("");
    const list = useMemo(() => data.contacts.filter((c) => filtType ? c.type === filtType : true).filter((c) => q ? (c.nom + " " + (c.courriel || "") + " " + (c.note || "")).toLowerCase().includes(q.toLowerCase()) : true).sort((a, b) => a.nom.localeCompare(b.nom)), [data.contacts, q, filtType]);
    const open = openId ? data.contacts.find((c) => c.id === openId) : null;
    return /* @__PURE__ */ React.createElement("div", { className: "page" }, /* @__PURE__ */ React.createElement("header", { className: "page-head row" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "kicker" }, "R\xE9pertoire"), /* @__PURE__ */ React.createElement("h1", null, "Qui gravite autour du 961.")), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", onClick: onNew }, "+ Nouveau contact")), /* @__PURE__ */ React.createElement("div", { className: "toolbar" }, /* @__PURE__ */ React.createElement("input", { className: "search", placeholder: "Chercher un nom, un courriel\u2026", value: q, onChange: (e) => setQ(e.target.value) }), /* @__PURE__ */ React.createElement("div", { className: "filters" }, /* @__PURE__ */ React.createElement("button", { className: "pill" + (filtType === "" ? " on" : ""), onClick: () => setFiltType("") }, "Tous"), TYPES.map((t) => /* @__PURE__ */ React.createElement("button", { key: t.id, className: "pill" + (filtType === t.id ? " on" : ""), onClick: () => setFiltType(t.id) }, t.label)))), list.length === 0 ? /* @__PURE__ */ React.createElement(Empty, null, "Aucun contact ici. Ajoute la premi\xE8re personne \u2014 un\xB7e artisan\xB7e, un\xB7e apprenant\xB7e, un prospect.") : /* @__PURE__ */ React.createElement("table", { className: "tbl full" }, /* @__PURE__ */ React.createElement("thead", null, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", null, "Nom"), /* @__PURE__ */ React.createElement("th", null, "Type"), /* @__PURE__ */ React.createElement("th", null, "\xC9cole"), /* @__PURE__ */ React.createElement("th", null, "Statut"), /* @__PURE__ */ React.createElement("th", null, "Infolettre"))), /* @__PURE__ */ React.createElement("tbody", null, list.map((c) => {
      const e = ecole(c.ecole);
      return /* @__PURE__ */ React.createElement("tr", { key: c.id, className: "clickrow", onClick: () => setOpen(c.id) }, /* @__PURE__ */ React.createElement("td", { className: "strong" }, c.nom), /* @__PURE__ */ React.createElement("td", null, /* @__PURE__ */ React.createElement("span", { className: "chip" }, typeLabel(c.type))), /* @__PURE__ */ React.createElement("td", null, e ? /* @__PURE__ */ React.createElement("span", { className: "ecole-tag" }, /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: e.color } }), e.label) : /* @__PURE__ */ React.createElement("span", { className: "dim" }, "\u2014")), /* @__PURE__ */ React.createElement("td", { className: "mono tiny" }, c.statut), /* @__PURE__ */ React.createElement("td", null, isAbonne(c) ? /* @__PURE__ */ React.createElement("span", { className: "ecole-tag" }, /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: "var(--soigner)" } }), "abonn\xE9\xB7e") : /* @__PURE__ */ React.createElement("span", { className: "dim tiny" }, "\u2014")));
    }))), open && /* @__PURE__ */ React.createElement(
      ContactDrawer,
      {
        c: open,
        reservations: reservations.filter((r) => r.contactId === open.id),
        onClose: () => setOpen(null),
        onEdit: () => onEdit(open),
        onDelete: () => onDelete(open.id),
        onInteraction: (t) => onInteraction(open.id, t),
        setAbo
      }
    ));
  }
  function ContactDrawer({ c, reservations, onClose, onEdit, onDelete, onInteraction, setAbo }) {
    const [note, setNote] = useState("");
    const e = ecole(c.ecole);
    const abo = isAbonne(c);
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "scrim", onClick: onClose }), /* @__PURE__ */ React.createElement("aside", { className: "drawer" }, /* @__PURE__ */ React.createElement("div", { className: "drawer-head" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "chip" }, typeLabel(c.type)), e && /* @__PURE__ */ React.createElement("span", { className: "ecole-tag inline" }, /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: e.color } }), e.label)), /* @__PURE__ */ React.createElement("button", { className: "x", onClick: onClose }, "\xD7")), /* @__PURE__ */ React.createElement("h2", { className: "drawer-name" }, c.nom), /* @__PURE__ */ React.createElement("div", { className: "mono tiny dim" }, c.statut, " \xB7 ajout\xE9 le ", fmtDate(c.ajoute)), /* @__PURE__ */ React.createElement("dl", { className: "deflist" }, c.courriel && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("dt", null, "Courriel"), /* @__PURE__ */ React.createElement("dd", null, /* @__PURE__ */ React.createElement("a", { href: "mailto:" + c.courriel }, c.courriel))), c.telephone && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("dt", null, "T\xE9l\xE9phone"), /* @__PURE__ */ React.createElement("dd", null, c.telephone)), c.note && /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("dt", null, "Note"), /* @__PURE__ */ React.createElement("dd", null, c.note))), /* @__PURE__ */ React.createElement("div", { className: "drawer-block" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Infolettre"), /* @__PURE__ */ React.createElement("div", { className: "abo-row" }, /* @__PURE__ */ React.createElement("div", null, abo ? /* @__PURE__ */ React.createElement("span", { className: "ecole-tag" }, /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: "var(--soigner)" } }), "abonn\xE9\xB7e") : /* @__PURE__ */ React.createElement("span", { className: "dim" }, "non abonn\xE9\xB7e"), abo && c.infolettre.consentement && /* @__PURE__ */ React.createElement("div", { className: "mono tiny dim", style: { marginTop: 3 } }, "consentement ", fmtDate(c.infolettre.consentement), " \xB7 ", c.infolettre.source || "\u2014")), /* @__PURE__ */ React.createElement("button", { className: "btn btn-ghost", disabled: !c.courriel, onClick: () => setAbo(c.id, !abo) }, abo ? "D\xE9sabonner" : "Abonner")), !c.courriel && /* @__PURE__ */ React.createElement("p", { className: "dim tiny" }, "Ajoute un courriel pour pouvoir l'abonner.")), reservations.length > 0 && /* @__PURE__ */ React.createElement("div", { className: "drawer-block" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "R\xE9servations"), /* @__PURE__ */ React.createElement("ul", { className: "mini-list" }, reservations.sort((a, b) => b.date.localeCompare(a.date)).map((r) => /* @__PURE__ */ React.createElement("li", { key: r.id }, /* @__PURE__ */ React.createElement("span", null, fmtDate(r.date), " \xB7 ", r.espace), /* @__PURE__ */ React.createElement("span", { className: "mono tiny" }, money(r.prix)))))), /* @__PURE__ */ React.createElement("div", { className: "drawer-block" }, /* @__PURE__ */ React.createElement("span", { className: "kicker dim" }, "Suivi"), /* @__PURE__ */ React.createElement("div", { className: "addnote" }, /* @__PURE__ */ React.createElement(
      "input",
      {
        placeholder: "Noter un \xE9change, un rappel\u2026",
        value: note,
        onChange: (ev) => setNote(ev.target.value),
        onKeyDown: (ev) => {
          if (ev.key === "Enter" && note.trim()) {
            onInteraction(note.trim());
            setNote("");
          }
        }
      }
    ), /* @__PURE__ */ React.createElement("button", { className: "btn btn-ghost", onClick: () => {
      if (note.trim()) {
        onInteraction(note.trim());
        setNote("");
      }
    } }, "Ajouter")), (c.interactions || []).length === 0 ? /* @__PURE__ */ React.createElement("p", { className: "dim tiny" }, "Aucune note pour l'instant.") : /* @__PURE__ */ React.createElement("ul", { className: "timeline" }, c.interactions.map((it) => /* @__PURE__ */ React.createElement("li", { key: it.id }, /* @__PURE__ */ React.createElement("span", { className: "mono tiny dim" }, fmtDate(it.date)), /* @__PURE__ */ React.createElement("span", null, it.texte))))), /* @__PURE__ */ React.createElement("div", { className: "drawer-actions" }, /* @__PURE__ */ React.createElement("button", { className: "btn", onClick: onEdit }, "Modifier"), /* @__PURE__ */ React.createElement("button", { className: "btn btn-danger", onClick: () => {
      if (confirm("Retirer " + c.nom + " ?")) onDelete();
    } }, "Retirer"))));
  }
  function Location({ data, contactById, onNew, onEdit, onDelete }) {
    const [filt, setFilt] = useState("avenir");
    const rows = useMemo(() => {
      let r = data.reservations.slice();
      if (filt === "avenir") r = r.filter((x) => x.date >= todayISO());
      return r.sort((a, b) => a.date.localeCompare(b.date));
    }, [data.reservations, filt]);
    const totalConfirme = data.reservations.filter((r) => r.paiement !== "devis").reduce((s, r) => s + (Number(r.prix) || 0), 0);
    return /* @__PURE__ */ React.createElement("div", { className: "page" }, /* @__PURE__ */ React.createElement("header", { className: "page-head row" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "kicker" }, "Location \xB7 salles + studio"), /* @__PURE__ */ React.createElement("h1", null, "Le revenu qui revient chaque semaine.")), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", onClick: onNew }, "+ R\xE9servation")), /* @__PURE__ */ React.createElement("div", { className: "banner" }, /* @__PURE__ */ React.createElement("span", { className: "mono tiny dim" }, "Total confirm\xE9 + encaiss\xE9"), /* @__PURE__ */ React.createElement("span", { className: "banner-num" }, money(totalConfirme))), /* @__PURE__ */ React.createElement("div", { className: "filters" }, /* @__PURE__ */ React.createElement("button", { className: "pill" + (filt === "avenir" ? " on" : ""), onClick: () => setFilt("avenir") }, "\xC0 venir"), /* @__PURE__ */ React.createElement("button", { className: "pill" + (filt === "tout" ? " on" : ""), onClick: () => setFilt("tout") }, "Tout")), rows.length === 0 ? /* @__PURE__ */ React.createElement(Empty, null, "Aucune r\xE9servation. Chaque case remplie, c'est du r\xE9current. Commence par une location r\xE9guli\xE8re.") : /* @__PURE__ */ React.createElement("table", { className: "tbl full" }, /* @__PURE__ */ React.createElement("thead", null, /* @__PURE__ */ React.createElement("tr", null, /* @__PURE__ */ React.createElement("th", null, "Date"), /* @__PURE__ */ React.createElement("th", null, "Espace"), /* @__PURE__ */ React.createElement("th", null, "Cr\xE9neau"), /* @__PURE__ */ React.createElement("th", null, "Qui"), /* @__PURE__ */ React.createElement("th", null, "R\xE9currence"), /* @__PURE__ */ React.createElement("th", null, "Prix"), /* @__PURE__ */ React.createElement("th", null, "Statut"), /* @__PURE__ */ React.createElement("th", null))), /* @__PURE__ */ React.createElement("tbody", null, rows.map((r) => {
      const c = contactById(r.contactId);
      const p = paie(r.paiement);
      return /* @__PURE__ */ React.createElement("tr", { key: r.id, className: "clickrow", onClick: () => onEdit(r) }, /* @__PURE__ */ React.createElement("td", { className: "mono nowrap" }, fmtDate(r.date)), /* @__PURE__ */ React.createElement("td", { className: "strong" }, r.espace), /* @__PURE__ */ React.createElement("td", { className: "mono tiny" }, r.debut || "\u2014", r.fin ? "\u2013" + r.fin : ""), /* @__PURE__ */ React.createElement("td", { className: "dim" }, c ? c.nom : "\u2014"), /* @__PURE__ */ React.createElement("td", { className: "tiny" }, r.recurrence), /* @__PURE__ */ React.createElement("td", { className: "mono nowrap" }, money(r.prix)), /* @__PURE__ */ React.createElement("td", null, /* @__PURE__ */ React.createElement(Badge, { color: p.color, label: p.label })), /* @__PURE__ */ React.createElement("td", { onClick: (e) => e.stopPropagation() }, /* @__PURE__ */ React.createElement("button", { className: "x small", onClick: () => {
        if (confirm("Retirer cette r\xE9servation ?")) onDelete(r.id);
      } }, "\xD7")));
    }))));
  }
  function Ateliers({ data, contactById, onNew, onEdit, onDelete }) {
    const rows = data.ateliers.slice().sort((a, b) => (b.date || "").localeCompare(a.date || ""));
    return /* @__PURE__ */ React.createElement("div", { className: "page" }, /* @__PURE__ */ React.createElement("header", { className: "page-head row" }, /* @__PURE__ */ React.createElement("div", null, /* @__PURE__ */ React.createElement("span", { className: "kicker" }, "Ateliers au Centre"), /* @__PURE__ */ React.createElement("h1", null, "Ce qui se transmet au 961.")), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", onClick: onNew }, "+ Atelier")), rows.length === 0 ? /* @__PURE__ */ React.createElement(Empty, null, "Aucun atelier. Programme le premier \u2014 une date, un\xB7e artisan\xB7e, une \xE9cole.") : /* @__PURE__ */ React.createElement("div", { className: "cards-grid" }, rows.map((a) => {
      const e = ecole(a.ecole);
      const art = contactById(a.artisanId);
      const taux = a.capacite ? Math.round((Number(a.inscrits) || 0) / a.capacite * 100) : 0;
      return /* @__PURE__ */ React.createElement("div", { key: a.id, className: "atelier-card", onClick: () => onEdit(a) }, /* @__PURE__ */ React.createElement("div", { className: "ac-accent", style: { background: e ? e.color : "var(--line)" } }), /* @__PURE__ */ React.createElement("div", { className: "ac-body" }, /* @__PURE__ */ React.createElement("div", { className: "ac-meta mono tiny" }, fmtDate(a.date)), /* @__PURE__ */ React.createElement("h3", null, a.titre), /* @__PURE__ */ React.createElement("div", { className: "ac-art dim" }, art ? art.nom : "artisan\xB7e \xE0 confirmer"), e && /* @__PURE__ */ React.createElement("div", { className: "ecole-tag" }, /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: e.color } }), e.label), /* @__PURE__ */ React.createElement("div", { className: "ac-foot" }, /* @__PURE__ */ React.createElement("span", { className: "mono tiny" }, money(a.prix)), a.capacite ? /* @__PURE__ */ React.createElement("span", { className: "mono tiny dim" }, a.inscrits || 0, "/", a.capacite, " \xB7 ", taux, "%") : null), a.capacite ? /* @__PURE__ */ React.createElement("div", { className: "bar" }, /* @__PURE__ */ React.createElement("span", { style: { width: Math.min(taux, 100) + "%", background: e ? e.color : "var(--cultiver)" } })) : null));
    })));
  }
  function Modal({ title, children, onClose }) {
    return /* @__PURE__ */ React.createElement(React.Fragment, null, /* @__PURE__ */ React.createElement("div", { className: "scrim", onClick: onClose }), /* @__PURE__ */ React.createElement("div", { className: "modal" }, /* @__PURE__ */ React.createElement("div", { className: "modal-head" }, /* @__PURE__ */ React.createElement("h2", null, title), /* @__PURE__ */ React.createElement("button", { className: "x", onClick: onClose }, "\xD7")), /* @__PURE__ */ React.createElement("div", { className: "modal-body" }, children)));
  }
  function Field({ label, children }) {
    return /* @__PURE__ */ React.createElement("label", { className: "field" }, /* @__PURE__ */ React.createElement("span", null, label), children);
  }
  function ContactForm({ modal, onSave, onClose }) {
    const base = modal.entity ? normalizeC(modal.entity) : {
      id: uid(),
      nom: "",
      type: "apprenante",
      ecole: "",
      courriel: "",
      telephone: "",
      statut: "Nouveau",
      etiquettes: [],
      note: "",
      interactions: [],
      ajoute: todayISO(),
      infolettre: emptyInfo()
    };
    function normalizeC(c) {
      return { ...c, infolettre: { ...emptyInfo(), ...c.infolettre || {} } };
    }
    const [f, setF] = useState(base);
    const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
    const setAbonne = (on) => setF((s) => {
      const info = { ...emptyInfo(), ...s.infolettre };
      if (on) {
        info.abonne = true;
        info.desabonne = false;
        if (!info.consentement) info.consentement = todayISO();
        if (!info.source) info.source = "manuel";
      } else {
        info.abonne = false;
        info.desabonne = true;
      }
      return { ...s, infolettre: info };
    });
    const valid = f.nom.trim().length > 0;
    const abo = f.infolettre && f.infolettre.abonne && !f.infolettre.desabonne;
    return /* @__PURE__ */ React.createElement(Modal, { title: modal.mode === "add" ? "Nouveau contact" : "Modifier le contact", onClose }, /* @__PURE__ */ React.createElement(Field, { label: "Nom" }, /* @__PURE__ */ React.createElement("input", { value: f.nom, onChange: (e) => set("nom", e.target.value), autoFocus: true })), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Type" }, /* @__PURE__ */ React.createElement("select", { value: f.type, onChange: (e) => set("type", e.target.value) }, TYPES.map((t) => /* @__PURE__ */ React.createElement("option", { key: t.id, value: t.id }, t.label)))), /* @__PURE__ */ React.createElement(Field, { label: "\xC9cole (si pertinent)" }, /* @__PURE__ */ React.createElement("select", { value: f.ecole, onChange: (e) => set("ecole", e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014"), ECOLES.map((e) => /* @__PURE__ */ React.createElement("option", { key: e.id, value: e.id }, e.label))))), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Courriel" }, /* @__PURE__ */ React.createElement("input", { type: "email", value: f.courriel, onChange: (e) => set("courriel", e.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "T\xE9l\xE9phone" }, /* @__PURE__ */ React.createElement("input", { value: f.telephone, onChange: (e) => set("telephone", e.target.value) }))), /* @__PURE__ */ React.createElement(Field, { label: "Statut" }, /* @__PURE__ */ React.createElement("select", { value: f.statut, onChange: (e) => set("statut", e.target.value) }, STATUTS.map((s) => /* @__PURE__ */ React.createElement("option", { key: s, value: s }, s)))), /* @__PURE__ */ React.createElement(Field, { label: "Note" }, /* @__PURE__ */ React.createElement("textarea", { rows: 2, value: f.note, onChange: (e) => set("note", e.target.value) })), /* @__PURE__ */ React.createElement("label", { className: "consent-inline" }, /* @__PURE__ */ React.createElement("input", { type: "checkbox", checked: abo, disabled: !f.courriel, onChange: (e) => setAbonne(e.target.checked) }), /* @__PURE__ */ React.createElement("span", null, "Abonn\xE9\xB7e \xE0 l'infolettre ", f.courriel ? "" : "(ajoute un courriel d'abord)", abo && f.infolettre.consentement ? " \xB7 depuis le " + fmtDate(f.infolettre.consentement) : "")), /* @__PURE__ */ React.createElement("div", { className: "modal-actions" }, /* @__PURE__ */ React.createElement("button", { className: "btn btn-ghost", onClick: onClose }, "Annuler"), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", disabled: !valid, onClick: () => onSave(f) }, "Enregistrer")));
  }
  function ReservationForm({ modal, contacts, onSave, onClose }) {
    const base = modal.entity || { id: uid(), contactId: "", espace: ESPACES[0], date: todayISO(), debut: "", fin: "", prix: "", recurrence: "Ponctuel", paiement: "devis", note: "" };
    const [f, setF] = useState(base);
    const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
    return /* @__PURE__ */ React.createElement(Modal, { title: modal.mode === "add" ? "Nouvelle r\xE9servation" : "Modifier la r\xE9servation", onClose }, /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Espace" }, /* @__PURE__ */ React.createElement("input", { list: "espaces", value: f.espace, onChange: (e) => set("espace", e.target.value) }), /* @__PURE__ */ React.createElement("datalist", { id: "espaces" }, ESPACES.map((s) => /* @__PURE__ */ React.createElement("option", { key: s, value: s })))), /* @__PURE__ */ React.createElement(Field, { label: "Date" }, /* @__PURE__ */ React.createElement("input", { type: "date", value: f.date, onChange: (e) => set("date", e.target.value) }))), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "D\xE9but" }, /* @__PURE__ */ React.createElement("input", { type: "time", value: f.debut, onChange: (e) => set("debut", e.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "Fin" }, /* @__PURE__ */ React.createElement("input", { type: "time", value: f.fin, onChange: (e) => set("fin", e.target.value) }))), /* @__PURE__ */ React.createElement(Field, { label: "Qui loue" }, /* @__PURE__ */ React.createElement("select", { value: f.contactId, onChange: (e) => set("contactId", e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 (\xE0 pr\xE9ciser)"), contacts.slice().sort((a, b) => a.nom.localeCompare(b.nom)).map((c) => /* @__PURE__ */ React.createElement("option", { key: c.id, value: c.id }, c.nom)))), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Prix (CAD)" }, /* @__PURE__ */ React.createElement("input", { type: "number", min: "0", value: f.prix, onChange: (e) => set("prix", e.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "R\xE9currence" }, /* @__PURE__ */ React.createElement("select", { value: f.recurrence, onChange: (e) => set("recurrence", e.target.value) }, RECURRENCES.map((r) => /* @__PURE__ */ React.createElement("option", { key: r, value: r }, r))))), /* @__PURE__ */ React.createElement(Field, { label: "Statut de paiement" }, /* @__PURE__ */ React.createElement("div", { className: "seg" }, PAIEMENTS.map((p) => /* @__PURE__ */ React.createElement(
      "button",
      {
        key: p.id,
        type: "button",
        className: "seg-btn" + (f.paiement === p.id ? " on" : ""),
        style: f.paiement === p.id ? { borderColor: p.color, color: p.color } : {},
        onClick: () => set("paiement", p.id)
      },
      p.label
    )))), /* @__PURE__ */ React.createElement("div", { className: "modal-actions" }, /* @__PURE__ */ React.createElement("button", { className: "btn btn-ghost", onClick: onClose }, "Annuler"), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", onClick: () => onSave(f) }, "Enregistrer")));
  }
  function AtelierForm({ modal, contacts, onSave, onClose }) {
    const artisanes = contacts.filter((c) => c.type === "artisane");
    const base = modal.entity || { id: uid(), titre: "", artisanId: "", ecole: "soigner", date: todayISO(), capacite: "", inscrits: "", prix: "", note: "" };
    const [f, setF] = useState(base);
    const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
    const valid = f.titre.trim().length > 0;
    return /* @__PURE__ */ React.createElement(Modal, { title: modal.mode === "add" ? "Nouvel atelier" : "Modifier l'atelier", onClose }, /* @__PURE__ */ React.createElement(Field, { label: "Titre" }, /* @__PURE__ */ React.createElement("input", { value: f.titre, onChange: (e) => set("titre", e.target.value), autoFocus: true })), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Artisan\xB7e" }, /* @__PURE__ */ React.createElement("select", { value: f.artisanId, onChange: (e) => set("artisanId", e.target.value) }, /* @__PURE__ */ React.createElement("option", { value: "" }, "\u2014 \xE0 confirmer"), artisanes.map((c) => /* @__PURE__ */ React.createElement("option", { key: c.id, value: c.id }, c.nom)))), /* @__PURE__ */ React.createElement(Field, { label: "\xC9cole" }, /* @__PURE__ */ React.createElement("select", { value: f.ecole, onChange: (e) => set("ecole", e.target.value) }, ECOLES.map((e) => /* @__PURE__ */ React.createElement("option", { key: e.id, value: e.id }, e.label))))), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Date" }, /* @__PURE__ */ React.createElement("input", { type: "date", value: f.date, onChange: (e) => set("date", e.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "Prix (CAD)" }, /* @__PURE__ */ React.createElement("input", { type: "number", min: "0", value: f.prix, onChange: (e) => set("prix", e.target.value) }))), /* @__PURE__ */ React.createElement("div", { className: "field-row" }, /* @__PURE__ */ React.createElement(Field, { label: "Capacit\xE9" }, /* @__PURE__ */ React.createElement("input", { type: "number", min: "0", value: f.capacite, onChange: (e) => set("capacite", e.target.value) })), /* @__PURE__ */ React.createElement(Field, { label: "Inscrits" }, /* @__PURE__ */ React.createElement("input", { type: "number", min: "0", value: f.inscrits, onChange: (e) => set("inscrits", e.target.value) }))), /* @__PURE__ */ React.createElement("div", { className: "modal-actions" }, /* @__PURE__ */ React.createElement("button", { className: "btn btn-ghost", onClick: onClose }, "Annuler"), /* @__PURE__ */ React.createElement("button", { className: "btn btn-primary", disabled: !valid, onClick: () => onSave(f) }, "Enregistrer")));
  }
  function Badge({ color, label }) {
    return /* @__PURE__ */ React.createElement("span", { className: "badge" }, /* @__PURE__ */ React.createElement("span", { className: "dot", style: { background: color } }), label);
  }
  function Empty({ children, small }) {
    return /* @__PURE__ */ React.createElement("div", { className: "empty" + (small ? " small" : "") }, children);
  }
  function Loading() {
    return /* @__PURE__ */ React.createElement("div", { className: "loading" }, /* @__PURE__ */ React.createElement(Style, null), /* @__PURE__ */ React.createElement("span", { className: "mono" }, "Chargement\u2026"));
  }
  function ExportMenu({ data, onReset }) {
    const download = (name, text, mime) => {
      const blob = new Blob([text], { type: mime });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = name;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1e3);
    };
    const exportJSON = () => download("soha_crm_" + todayISO().replace(/-/g, "") + ".json", JSON.stringify(data, null, 2), "application/json");
    const exportCSV = () => {
      const head = ["nom", "type", "ecole", "statut", "courriel", "telephone", "note"];
      const lines = [head.join(",")].concat(data.contacts.map((c) => head.map((k) => '"' + String(c[k] || "").replace(/"/g, '""') + '"').join(",")));
      download("soha_contacts_" + todayISO().replace(/-/g, "") + ".csv", lines.join("\n"), "text/csv");
    };
    return /* @__PURE__ */ React.createElement("div", { className: "export" }, /* @__PURE__ */ React.createElement("button", { className: "btn btn-mini", onClick: exportCSV }, "Exporter contacts (CSV)"), /* @__PURE__ */ React.createElement("button", { className: "btn btn-mini", onClick: exportJSON }, "Sauvegarde (JSON)"), /* @__PURE__ */ React.createElement("button", { className: "btn btn-mini danger", onClick: () => {
      if (confirm("Tout r\xE9initialiser ? Les donn\xE9es actuelles seront perdues.")) onReset();
    } }, "R\xE9initialiser"));
  }
  function Style() {
    return /* @__PURE__ */ React.createElement("style", null, `
#soha-crm-racine .soha,#soha-crm-racine .loading{--encre:#0E1A15; --ivoire:#F4F0E7; --soigner:#19A7DB; --batir:#D29A4E; --cultiver:#5E8C5A; --cramoisi:#AE1E3B;
  --line:rgba(14,26,21,.14); --muted:rgba(14,26,21,.55); --surface:#FBFAF5;
  --serif:'Fraunces',Georgia,serif; --sans:'Schibsted Grotesk',system-ui,sans-serif; --mono:'DM Mono',ui-monospace,monospace;}
#soha-crm-racine .soha *{box-sizing:border-box;}
#soha-crm-racine .soha{display:flex; min-height:calc(100vh - 32px); background:var(--ivoire); color:var(--encre); font-family:var(--sans); font-size:15px; line-height:1.5;}
#soha-crm-racine .loading{display:flex;align-items:center;justify-content:center;min-height:calc(100vh - 32px);background:var(--ivoire);color:var(--muted);}
#soha-crm-racine .rail{width:236px; flex:0 0 236px; background:var(--encre); color:var(--ivoire); display:flex; flex-direction:column; padding:22px 16px; position:sticky; top:0; height:100vh;}
#soha-crm-racine .brand{display:flex; gap:10px; align-items:center; margin-bottom:26px; padding:0 4px;}
#soha-crm-racine .brand-mark{color:var(--soigner); font-size:22px; line-height:1;}
#soha-crm-racine .brand-name{font-family:var(--serif); font-size:18px; font-weight:600;}
#soha-crm-racine .brand-sub{font-family:var(--mono); font-size:11px; letter-spacing:.04em; opacity:.6;}
#soha-crm-racine nav{display:flex; flex-direction:column; gap:2px;}
#soha-crm-racine .navlink{background:none; border:0; text-align:left; color:rgba(244,240,231,.72); font-family:var(--sans); font-size:15px; padding:9px 12px; border-radius:8px; cursor:pointer;}
#soha-crm-racine .navlink:hover{background:rgba(244,240,231,.07); color:var(--ivoire);}
#soha-crm-racine .navlink.on{background:rgba(25,167,219,.16); color:#fff;}
#soha-crm-racine .rail-foot{margin-top:auto; padding-top:16px;}
#soha-crm-racine .export{display:flex; flex-direction:column; gap:6px; margin-bottom:12px;}
#soha-crm-racine .rail-note{font-family:var(--mono); font-size:10.5px; line-height:1.4; color:rgba(244,240,231,.4);}
#soha-crm-racine .main{flex:1; min-width:0; overflow:auto; height:100vh;}
#soha-crm-racine .page{max-width:1120px; margin:0 auto; padding:40px 44px 80px;}
#soha-crm-racine .page-head{margin-bottom:26px;}
#soha-crm-racine .page-head.row{display:flex; justify-content:space-between; align-items:flex-end; gap:16px;}
#soha-crm-racine .page-head h1{font-family:var(--serif); font-weight:600; font-size:clamp(26px,3.4vw,40px); line-height:1.05; margin:4px 0 0; letter-spacing:-.01em;}
#soha-crm-racine .kicker{font-family:var(--mono); font-size:11px; letter-spacing:.12em; text-transform:uppercase; color:var(--encre);}
#soha-crm-racine .kicker.dim{color:var(--muted);}
#soha-crm-racine .grid{display:grid; grid-template-columns:1.4fr 1fr 1fr; gap:16px; margin-bottom:16px;}
#soha-crm-racine .two-col{display:grid; grid-template-columns:1.4fr 1fr; gap:16px;}
#soha-crm-racine .info-grid{display:grid; grid-template-columns:1fr 1.4fr; gap:16px; margin-bottom:20px;}
#soha-crm-racine .card{background:var(--surface); border:1px solid var(--line); border-radius:12px; padding:20px 22px;}
#soha-crm-racine .card-head{margin-bottom:12px;}
#soha-crm-racine .hero-card{background:var(--encre); color:var(--ivoire); border:0;}
#soha-crm-racine .hero-num{font-family:var(--serif); font-size:clamp(40px,6vw,64px); font-weight:600; line-height:1; margin:10px 0 6px;}
#soha-crm-racine .hero-sub{font-size:14px; color:rgba(244,240,231,.75);}
#soha-crm-racine .hero-sub strong{color:var(--soigner); font-weight:600;}
#soha-crm-racine .hero-tag{margin-top:16px; font-family:var(--mono); font-size:11px; letter-spacing:.04em; color:rgba(244,240,231,.5);}
#soha-crm-racine .stat{font-family:var(--serif); font-size:44px; font-weight:600; line-height:1; margin:8px 0 14px;}
#soha-crm-racine .type-list{display:flex; flex-direction:column; gap:7px;}
#soha-crm-racine .type-row{display:flex; justify-content:space-between; font-size:13.5px; padding-bottom:6px; border-bottom:1px solid var(--line);}
#soha-crm-racine .type-row:last-child{border:0; padding:0;}
#soha-crm-racine .mini-list{list-style:none; margin:8px 0 0; padding:0; display:flex; flex-direction:column; gap:8px;}
#soha-crm-racine .mini-list li{display:flex; justify-content:space-between; align-items:center; gap:10px; font-size:13.5px;}
#soha-crm-racine .linkish{background:none; border:0; color:var(--encre); font-family:var(--sans); font-size:13.5px; cursor:pointer; padding:0; text-align:left; border-bottom:1px solid transparent;}
#soha-crm-racine .linkish:hover{border-color:var(--encre);}
#soha-crm-racine .atelier-mini{list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:12px;}
#soha-crm-racine .am-top{display:flex; align-items:center; gap:8px;}
#soha-crm-racine .am-title{font-weight:500;}
#soha-crm-racine .am-meta{margin-top:2px;}
#soha-crm-racine .tbl{width:100%; border-collapse:collapse; font-size:13.5px;}
#soha-crm-racine .tbl.full{background:var(--surface); border:1px solid var(--line); border-radius:12px; overflow:hidden;}
#soha-crm-racine .tbl th{text-align:left; font-family:var(--mono); font-size:10.5px; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); font-weight:400; padding:12px 16px; border-bottom:1px solid var(--line);}
#soha-crm-racine .tbl td{padding:12px 16px; border-bottom:1px solid var(--line); vertical-align:middle;}
#soha-crm-racine .tbl.full tbody tr:last-child td{border-bottom:0;}
#soha-crm-racine .tbl tbody tr:last-child td{border-bottom:0;}
#soha-crm-racine .clickrow{cursor:pointer;}
#soha-crm-racine .clickrow:hover{background:rgba(25,167,219,.05);}
#soha-crm-racine .strong{font-weight:600;}
#soha-crm-racine .dim{color:var(--muted);}
#soha-crm-racine .tiny{font-size:11.5px;}
#soha-crm-racine .mono{font-family:var(--mono);}
#soha-crm-racine .nowrap{white-space:nowrap;}
#soha-crm-racine .chip{display:inline-block; font-family:var(--mono); font-size:11px; letter-spacing:.03em; border:1px solid var(--line); border-radius:20px; padding:2px 10px;}
#soha-crm-racine .dot{display:inline-block; width:8px; height:8px; border-radius:50%; flex:0 0 8px;}
#soha-crm-racine .badge{display:inline-flex; align-items:center; gap:6px; font-size:12px; font-family:var(--mono);}
#soha-crm-racine .ecole-tag{display:inline-flex; align-items:center; gap:6px; font-size:12px;}
#soha-crm-racine .ecole-tag.inline{margin-left:8px;}
#soha-crm-racine .toolbar{display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom:18px; flex-wrap:wrap;}
#soha-crm-racine .search{flex:1; min-width:220px; background:var(--surface); border:1px solid var(--line); border-radius:10px; padding:10px 14px; font-family:var(--sans); font-size:14px; color:var(--encre);}
#soha-crm-racine .search:focus{outline:2px solid var(--soigner); outline-offset:1px;}
#soha-crm-racine .filters{display:flex; gap:6px; flex-wrap:wrap;}
#soha-crm-racine .pill{background:none; border:1px solid var(--line); border-radius:20px; padding:6px 14px; font-family:var(--sans); font-size:13px; cursor:pointer; color:var(--muted);}
#soha-crm-racine .pill:hover{color:var(--encre);}
#soha-crm-racine .pill.on{background:var(--encre); color:var(--ivoire); border-color:var(--encre);}
#soha-crm-racine .banner{display:flex; align-items:baseline; gap:14px; background:var(--encre); color:var(--ivoire); border-radius:12px; padding:16px 22px; margin-bottom:18px;}
#soha-crm-racine .banner-num{font-family:var(--serif); font-size:30px; font-weight:600; color:var(--cultiver);}
#soha-crm-racine .btn{background:var(--surface); border:1px solid var(--line); border-radius:10px; padding:9px 16px; font-family:var(--sans); font-size:14px; cursor:pointer; color:var(--encre);}
#soha-crm-racine .btn:hover{border-color:var(--encre);}
#soha-crm-racine .btn:disabled{opacity:.4; cursor:not-allowed;}
#soha-crm-racine .btn-primary{background:var(--encre); color:var(--ivoire); border-color:var(--encre);}
#soha-crm-racine .btn-primary:hover{background:#16261f;}
#soha-crm-racine .btn-ghost{background:none;}
#soha-crm-racine .btn-danger{color:var(--cramoisi); border-color:rgba(174,30,59,.4);}
#soha-crm-racine .btn-mini{font-size:12px; padding:7px 10px; background:rgba(244,240,231,.06); color:rgba(244,240,231,.85); border-color:rgba(244,240,231,.14);}
#soha-crm-racine .btn-mini:hover{border-color:rgba(244,240,231,.4);}
#soha-crm-racine .btn-mini.danger{color:#e88;}
#soha-crm-racine .empty{background:var(--surface); border:1px dashed var(--line); border-radius:12px; padding:32px; text-align:center; color:var(--muted); font-size:14px; line-height:1.6;}
#soha-crm-racine .empty.small{padding:18px; font-size:13px; border:0; background:none;}
#soha-crm-racine .import-card{display:flex; flex-direction:column;}
#soha-crm-racine .import-box{background:#fff; border:1px solid var(--line); border-radius:10px; padding:10px 12px; font-family:var(--mono); font-size:12.5px; color:var(--encre); resize:vertical; width:100%;}
#soha-crm-racine .import-box:focus{outline:2px solid var(--soigner); outline-offset:1px;}
#soha-crm-racine .abo-row{display:flex; justify-content:space-between; align-items:center; gap:12px; margin-top:8px;}
#soha-crm-racine .scrim{position:fixed; inset:0; background:rgba(14,26,21,.4); z-index:40;}
#soha-crm-racine .drawer{position:fixed; top:0; right:0; width:min(440px,92vw); height:100vh; background:var(--ivoire); z-index:50; padding:24px 26px; overflow:auto; box-shadow:-8px 0 40px rgba(14,26,21,.18);}
#soha-crm-racine .drawer-head{display:flex; justify-content:space-between; align-items:flex-start;}
#soha-crm-racine .drawer-name{font-family:var(--serif); font-size:28px; font-weight:600; margin:12px 0 2px; line-height:1.1;}
#soha-crm-racine .deflist{display:grid; grid-template-columns:auto 1fr; gap:6px 16px; margin:20px 0;}
#soha-crm-racine .deflist dt{font-family:var(--mono); font-size:11px; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); padding-top:2px;}
#soha-crm-racine .deflist dd{margin:0; font-size:14px;}
#soha-crm-racine .deflist a{color:var(--soigner); text-decoration:none;}
#soha-crm-racine .drawer-block{margin-top:22px; padding-top:18px; border-top:1px solid var(--line);}
#soha-crm-racine .addnote{display:flex; gap:8px; margin:10px 0;}
#soha-crm-racine .addnote input{flex:1; background:var(--surface); border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-family:var(--sans); font-size:13.5px;}
#soha-crm-racine .timeline{list-style:none; margin:10px 0 0; padding:0; display:flex; flex-direction:column; gap:10px;}
#soha-crm-racine .timeline li{display:flex; flex-direction:column; gap:2px; font-size:13.5px; padding-left:12px; border-left:2px solid var(--line);}
#soha-crm-racine .drawer-actions{display:flex; gap:10px; margin-top:28px;}
#soha-crm-racine .x{background:none; border:0; font-size:24px; line-height:1; cursor:pointer; color:var(--muted); padding:0 4px;}
#soha-crm-racine .x:hover{color:var(--encre);}
#soha-crm-racine .x.small{font-size:18px;}
#soha-crm-racine .modal{position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); z-index:50; width:min(560px,94vw); max-height:90vh; overflow:auto; background:var(--ivoire); border-radius:16px; padding:26px 28px; box-shadow:0 20px 60px rgba(14,26,21,.28);}
#soha-crm-racine .modal-head{display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;}
#soha-crm-racine .modal-head h2{font-family:var(--serif); font-size:22px; font-weight:600; margin:0;}
#soha-crm-racine .field{display:flex; flex-direction:column; gap:5px; margin-bottom:14px;}
#soha-crm-racine .field>span{font-family:var(--mono); font-size:11px; text-transform:uppercase; letter-spacing:.05em; color:var(--muted);}
#soha-crm-racine .field input,#soha-crm-racine .field select,#soha-crm-racine .field textarea{background:var(--surface); border:1px solid var(--line); border-radius:9px; padding:9px 12px; font-family:var(--sans); font-size:14px; color:var(--encre); width:100%;}
#soha-crm-racine .field input:focus,#soha-crm-racine .field select:focus,#soha-crm-racine .field textarea:focus{outline:2px solid var(--soigner); outline-offset:1px;}
#soha-crm-racine .field-row{display:grid; grid-template-columns:1fr 1fr; gap:14px;}
#soha-crm-racine .consent-inline{display:flex; align-items:flex-start; gap:10px; margin:2px 0 18px; font-size:13.5px; line-height:1.4;}
#soha-crm-racine .consent-inline input{width:18px; height:18px; margin-top:1px; flex:0 0 18px; accent-color:var(--soigner);}
#soha-crm-racine .seg{display:flex; gap:8px;}
#soha-crm-racine .seg-btn{flex:1; background:var(--surface); border:1.5px solid var(--line); border-radius:9px; padding:9px; font-family:var(--sans); font-size:13px; cursor:pointer; color:var(--muted);}
#soha-crm-racine .seg-btn.on{font-weight:600;}
#soha-crm-racine .modal-actions{display:flex; justify-content:flex-end; gap:10px; margin-top:8px;}
#soha-crm-racine .cards-grid{display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:16px;}
#soha-crm-racine .atelier-card{display:flex; background:var(--surface); border:1px solid var(--line); border-radius:12px; overflow:hidden; cursor:pointer;}
#soha-crm-racine .atelier-card:hover{border-color:var(--encre);}
#soha-crm-racine .ac-accent{width:5px; flex:0 0 5px;}
#soha-crm-racine .ac-body{padding:16px 18px; flex:1;}
#soha-crm-racine .ac-body h3{font-family:var(--serif); font-size:19px; font-weight:600; margin:4px 0 4px; line-height:1.15;}
#soha-crm-racine .ac-art{font-size:13px; margin-bottom:8px;}
#soha-crm-racine .ac-foot{display:flex; justify-content:space-between; align-items:center; margin-top:12px;}
#soha-crm-racine .bar{height:5px; background:var(--line); border-radius:3px; overflow:hidden; margin-top:8px;}
#soha-crm-racine .bar span{display:block; height:100%;}
#soha-crm-racine .toast{position:fixed; bottom:24px; left:50%; transform:translateX(-50%); z-index:60; background:var(--encre); color:var(--ivoire); padding:11px 20px; border-radius:24px; font-size:13.5px; box-shadow:0 8px 24px rgba(14,26,21,.3);}
@media (max-width:860px){
#soha-crm-racine .soha{flex-direction:column;}
#soha-crm-racine .rail{width:100%; flex:none; height:auto; position:static; flex-direction:row; align-items:center; padding:12px 16px; gap:12px; overflow-x:auto;}
#soha-crm-racine .brand{margin-bottom:0;}
#soha-crm-racine nav{flex-direction:row; gap:2px;}
#soha-crm-racine .rail-foot{margin:0 0 0 auto; padding:0;}
#soha-crm-racine .export{flex-direction:row;}
#soha-crm-racine .rail-note{display:none;}
#soha-crm-racine .main{height:auto;}
#soha-crm-racine .page{padding:24px 18px 60px;}
#soha-crm-racine .grid,#soha-crm-racine .two-col,#soha-crm-racine .info-grid{grid-template-columns:1fr;}
#soha-crm-racine .field-row{grid-template-columns:1fr;}
}
`);
  }

  // ../../../tmp/claude-0/-home-user-centre-soha/e9238a31-e6e0-596c-a8e9-203c161bd00f/scratchpad/x/build_crm/soha-crm/_travail/entree.jsx
  var { createElement, createRoot, render } = window.wp.element;
  function demarrer() {
    const noeud = document.getElementById("soha-crm-racine");
    if (!noeud) return;
    if (typeof createRoot === "function") {
      createRoot(noeud).render(createElement(App));
    } else {
      render(createElement(App), noeud);
    }
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", demarrer);
  } else {
    demarrer();
  }
})();
