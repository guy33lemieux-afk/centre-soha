import React, { useState, useEffect, useMemo, useCallback } from "react";

/* ==========================================================================
   CRM — Centre Soha (961 Rachel Est) · v02
   Nouveau : couche INFOLETTRE — import des abonnés (export Cyberimpact),
   consentement daté par contact, export de la liste d'envoi.
   Les données restent dans TON navigateur. Rien de partagé.
   Canon v06 : ivoire #F4F0E7 / encre #0E1A15 ; Soigner #19A7DB · Bâtir #D29A4E · Cultiver #5E8C5A.
   ========================================================================== */

const STORE_KEY = "soha-crm:v1"; // même clé : tes données v01 se mettent à niveau toutes seules

const ECOLES = [
  { id: "soigner", label: "Soigner le vivant", color: "#19A7DB" },
  { id: "batir", label: "Bâtir le vivant", color: "#D29A4E" },
  { id: "cultiver", label: "Cultiver le vivant", color: "#5E8C5A" },
];
const ecole = (id) => ECOLES.find((e) => e.id === id);

const TYPES = [
  { id: "artisane", label: "Artisan·e" },
  { id: "apprenante", label: "Apprenant·e" },
  { id: "prospect", label: "Prospect" },
  { id: "partenaire", label: "Partenaire" },
];
const typeLabel = (id) => (TYPES.find((t) => t.id === id) || {}).label || id;

const STATUTS = ["Nouveau", "En discussion", "Actif", "Récurrent", "Dormant"];

const PAIEMENTS = [
  { id: "devis", label: "Devis", color: "#D29A4E" },
  { id: "confirme", label: "Confirmé", color: "#19A7DB" },
  { id: "paye", label: "Payé", color: "#5E8C5A" },
];
const paie = (id) => PAIEMENTS.find((p) => p.id === id) || PAIEMENTS[0];

const ESPACES = ["Grande salle", "Studio", "Petite salle"];
const RECURRENCES = ["Ponctuel", "Hebdomadaire", "Mensuel"];

const uid = () =>
  (window.crypto && window.crypto.randomUUID && window.crypto.randomUUID()) ||
  String(Date.now()) + Math.random().toString(16).slice(2);
const todayISO = () => new Date().toISOString().slice(0, 10);
const money = (n) => (Number(n) || 0).toLocaleString("fr-CA", { maximumFractionDigits: 0 }) + " $";
const fmtDate = (iso) => {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString("fr-CA", { day: "numeric", month: "short", year: "numeric" });
};
const monthLabel = () => new Date().toLocaleDateString("fr-CA", { month: "long", year: "numeric" });
const sameMonth = (iso) => {
  if (!iso) return false;
  const d = new Date(iso + "T00:00:00"), n = new Date();
  return d.getMonth() === n.getMonth() && d.getFullYear() === n.getFullYear();
};
const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const emptyInfo = () => ({ abonne: false, consentement: "", source: "", desabonne: false });
const isAbonne = (c) => c.infolettre && c.infolettre.abonne && !c.infolettre.desabonne;

/* Mise à niveau douce des contacts venus de v01 */
const normalizeContact = (c) => ({
  etiquettes: [],
  interactions: [],
  note: "",
  ecole: "",
  courriel: "",
  telephone: "",
  ...c,
  infolettre: { ...emptyInfo(), ...(c.infolettre || {}) },
});

const seed = () => {
  const artisanes = [
    ["Dominique Mennessier", "A·002 · co-associée"],
    ["Ève Morin", "A·004"],
    ["Jeimy Oviedo", "A·005"],
    ["Julie Habart", "A·011"],
    ["Marjolaine Blouin", "A·003"],
  ];
  const contacts = artisanes.map(([nom, note]) =>
    normalizeContact({
      id: uid(), nom, type: "artisane", statut: "Actif", note, ajoute: todayISO(),
    })
  );
  return { contacts, reservations: [], ateliers: [], v: 2 };
};

/* ================================ App ================================ */
export default function App() {
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("dashboard");
  const [modal, setModal] = useState(null);
  const [openContact, setOpenContact] = useState(null);
  const [toast, setToast] = useState("");

  useEffect(() => {
    let alive = true;
    (async () => {
      let loaded = null;
      try {
        if (window.storage) {
          const r = await window.storage.get(STORE_KEY);
          if (r && r.value) loaded = JSON.parse(r.value);
        }
      } catch (e) { loaded = null; }
      if (!loaded) loaded = seed();
      loaded.contacts = (loaded.contacts || []).map(normalizeContact);
      loaded.reservations = loaded.reservations || [];
      loaded.ateliers = loaded.ateliers || [];
      try { if (window.storage) await window.storage.set(STORE_KEY, JSON.stringify(loaded)); } catch (e) {}
      if (alive) setData(loaded);
    })();
    return () => { alive = false; };
  }, []);

  const persist = useCallback((next) => {
    setData(next);
    try { if (window.storage) window.storage.set(STORE_KEY, JSON.stringify(next)); } catch (e) {}
  }, []);
  const flash = (m) => { setToast(m); setTimeout(() => setToast(""), 2400); };

  const upsert = (col, entity) => {
    const list = data[col].slice();
    const i = list.findIndex((x) => x.id === entity.id);
    if (i >= 0) list[i] = entity; else list.unshift(entity);
    persist({ ...data, [col]: list });
  };
  const remove = (col, id) => persist({ ...data, [col]: data[col].filter((x) => x.id !== id) });
  const addInteraction = (contactId, texte) => {
    const list = data.contacts.map((c) =>
      c.id === contactId
        ? { ...c, interactions: [{ id: uid(), date: todayISO(), texte }, ...(c.interactions || [])] }
        : c
    );
    persist({ ...data, contacts: list });
  };
  const setAbo = (contactId, abonne) => {
    const list = data.contacts.map((c) => {
      if (c.id !== contactId) return c;
      const info = { ...emptyInfo(), ...c.infolettre };
      if (abonne) { info.abonne = true; info.desabonne = false; if (!info.consentement) info.consentement = todayISO(); if (!info.source) info.source = "manuel"; }
      else { info.abonne = false; info.desabonne = true; }
      return { ...c, infolettre: info };
    });
    persist({ ...data, contacts: list });
  };
  const importAbonnes = (parsed) => {
    let ajoutes = 0, maj = 0;
    const byMail = {};
    data.contacts.forEach((c) => { if (c.courriel) byMail[c.courriel.toLowerCase()] = c.id; });
    let list = data.contacts.slice();
    const vus = {};
    parsed.forEach((p) => {
      if (vus[p.courriel]) return;
      vus[p.courriel] = true;
      const existingId = byMail[p.courriel];
      if (existingId) {
        list = list.map((c) => c.id === existingId
          ? { ...c, infolettre: { abonne: true, desabonne: false, consentement: c.infolettre.consentement || todayISO(), source: c.infolettre.source || "import" } }
          : c);
        maj++;
      } else {
        list.unshift(normalizeContact({
          id: uid(), nom: p.prenom || p.courriel, type: "apprenante", courriel: p.courriel,
          statut: "Nouveau", ajoute: todayISO(),
          infolettre: { abonne: true, desabonne: false, consentement: todayISO(), source: "import" },
        }));
        ajoutes++;
      }
    });
    persist({ ...data, contacts: list });
    return { ajoutes, maj };
  };

  if (!data) return <Loading />;
  const contactById = (id) => data.contacts.find((c) => c.id === id);

  return (
    <div className="soha">
      <Style />
      <aside className="rail">
        <div className="brand">
          <span className="brand-mark">◦</span>
          <div>
            <div className="brand-name">Centre Soha</div>
            <div className="brand-sub">961 Rachel Est</div>
          </div>
        </div>
        <nav>
          {[
            ["dashboard", "Tableau de bord"],
            ["repertoire", "Répertoire"],
            ["infolettre", "Infolettre"],
            ["location", "Location"],
            ["ateliers", "Ateliers"],
          ].map(([id, label]) => (
            <button key={id} className={"navlink" + (tab === id ? " on" : "")} onClick={() => { setTab(id); setOpenContact(null); }}>
              {label}
            </button>
          ))}
        </nav>
        <div className="rail-foot">
          <ExportMenu data={data} onReset={() => { persist(seed()); flash("Répertoire réinitialisé."); }} />
          <div className="rail-note">Données gardées dans ton navigateur.</div>
        </div>
      </aside>

      <main className="main">
        {tab === "dashboard" && (
          <Dashboard data={data} contactById={contactById}
            openContact={(id) => { setTab("repertoire"); setOpenContact(id); }} />
        )}
        {tab === "repertoire" && (
          <Repertoire data={data} openId={openContact} setOpen={setOpenContact}
            onNew={() => setModal({ kind: "contact", mode: "add", entity: null })}
            onEdit={(c) => setModal({ kind: "contact", mode: "edit", entity: c })}
            onDelete={(id) => { remove("contacts", id); setOpenContact(null); flash("Contact retiré."); }}
            onInteraction={addInteraction} setAbo={setAbo} reservations={data.reservations} />
        )}
        {tab === "infolettre" && (
          <Infolettre data={data} onImport={importAbonnes} setAbo={setAbo}
            openContact={(id) => { setTab("repertoire"); setOpenContact(id); }} flash={flash} />
        )}
        {tab === "location" && (
          <Location data={data} contactById={contactById}
            onNew={() => setModal({ kind: "reservation", mode: "add", entity: null })}
            onEdit={(r) => setModal({ kind: "reservation", mode: "edit", entity: r })}
            onDelete={(id) => { remove("reservations", id); flash("Réservation retirée."); }} />
        )}
        {tab === "ateliers" && (
          <Ateliers data={data} contactById={contactById}
            onNew={() => setModal({ kind: "atelier", mode: "add", entity: null })}
            onEdit={(a) => setModal({ kind: "atelier", mode: "edit", entity: a })}
            onDelete={(id) => { remove("ateliers", id); flash("Atelier retiré."); }} />
        )}
      </main>

      {modal && modal.kind === "contact" && (
        <ContactForm modal={modal} onClose={() => setModal(null)}
          onSave={(c) => { upsert("contacts", c); setModal(null); flash("Contact enregistré."); }} />
      )}
      {modal && modal.kind === "reservation" && (
        <ReservationForm modal={modal} contacts={data.contacts} onClose={() => setModal(null)}
          onSave={(r) => { upsert("reservations", r); setModal(null); flash("Réservation enregistrée."); }} />
      )}
      {modal && modal.kind === "atelier" && (
        <AtelierForm modal={modal} contacts={data.contacts} onClose={() => setModal(null)}
          onSave={(a) => { upsert("ateliers", a); setModal(null); flash("Atelier enregistré."); }} />
      )}

      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

/* ============================ Tableau de bord ============================ */
function Dashboard({ data, contactById, openContact }) {
  const paye = data.reservations.filter((r) => r.paiement === "paye" && sameMonth(r.date)).reduce((s, r) => s + (Number(r.prix) || 0), 0);
  const aVenir = data.reservations.filter((r) => r.paiement === "confirme" && sameMonth(r.date)).reduce((s, r) => s + (Number(r.prix) || 0), 0);
  const parType = TYPES.map((t) => ({ ...t, n: data.contacts.filter((c) => c.type === t.id).length }));
  const nbAbonnes = data.contacts.filter(isAbonne).length;
  const prochaines = data.reservations.filter((r) => r.date >= todayISO()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 5);
  const prochainsAteliers = data.ateliers.filter((a) => a.date >= todayISO()).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
  const aRelancer = data.contacts.filter((c) => c.type === "prospect" || c.statut === "Nouveau" || c.statut === "En discussion" || c.statut === "Dormant").slice(0, 6);

  return (
    <div className="page">
      <header className="page-head"><span className="kicker">Centre Soha · {monthLabel()}</span><h1>Où on en est.</h1></header>
      <section className="grid">
        <div className="card hero-card">
          <span className="kicker dim">Revenu location · ce mois</span>
          <div className="hero-num">{money(paye)}</div>
          <div className="hero-sub">encaissé — <strong>{money(aVenir)}</strong> confirmé à venir</div>
          <div className="hero-tag">Salles + studio · le socle récurrent</div>
        </div>
        <div className="card">
          <span className="kicker dim">Répertoire</span>
          <div className="stat">{data.contacts.length}</div>
          <div className="type-list">
            {parType.map((t) => (
              <div key={t.id} className="type-row"><span className="type-name">{t.label}</span><span className="mono">{t.n}</span></div>
            ))}
            <div className="type-row"><span className="type-name">Abonnés infolettre</span><span className="mono" style={{ color: "var(--soigner)" }}>{nbAbonnes}</span></div>
          </div>
        </div>
        <div className="card">
          <span className="kicker dim">À relancer</span>
          {aRelancer.length === 0 ? <Empty small>Personne en attente. Beau travail.</Empty> : (
            <ul className="mini-list">
              {aRelancer.map((c) => (
                <li key={c.id}><button className="linkish" onClick={() => openContact(c.id)}>{c.nom}</button><span className="mono tiny">{c.statut}</span></li>
              ))}
            </ul>
          )}
        </div>
      </section>
      <section className="two-col">
        <div className="card">
          <div className="card-head"><span className="kicker dim">Prochaines réservations</span></div>
          {prochaines.length === 0 ? <Empty>Rien de réservé. Ouvre l'agenda des salles — c'est là que le revenu se joue.</Empty> : (
            <table className="tbl"><tbody>
              {prochaines.map((r) => {
                const c = contactById(r.contactId); const p = paie(r.paiement);
                return (<tr key={r.id}>
                  <td className="mono nowrap">{fmtDate(r.date)}</td><td>{r.espace}</td>
                  <td className="dim">{c ? c.nom : "—"}</td><td className="mono nowrap">{money(r.prix)}</td>
                  <td><Badge color={p.color} label={p.label} /></td></tr>);
              })}
            </tbody></table>
          )}
        </div>
        <div className="card">
          <div className="card-head"><span className="kicker dim">Prochains ateliers</span></div>
          {prochainsAteliers.length === 0 ? <Empty>Aucun atelier planifié.</Empty> : (
            <ul className="atelier-mini">
              {prochainsAteliers.map((a) => {
                const e = ecole(a.ecole); const art = contactById(a.artisanId);
                return (<li key={a.id}>
                  <div className="am-top">{e && <span className="dot" style={{ background: e.color }} />}<span className="am-title">{a.titre}</span></div>
                  <div className="am-meta mono tiny">{fmtDate(a.date)} · {art ? art.nom : "artisan·e à confirmer"}</div></li>);
              })}
            </ul>
          )}
        </div>
      </section>
    </div>
  );
}

/* ============================== Infolettre ============================== */
function Infolettre({ data, onImport, setAbo, openContact, flash }) {
  const [raw, setRaw] = useState("");
  const abonnes = data.contacts.filter(isAbonne).sort((a, b) => a.nom.localeCompare(b.nom));

  const parse = (text) => {
    const out = [];
    text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean).forEach((line) => {
      const cells = line.split(/[;,\t]/).map((c) => c.trim().replace(/^"|"$/g, ""));
      const email = cells.find((c) => emailRe.test(c));
      if (!email) return;
      const prenom = cells.find((c) => c && c !== email && !/@/.test(c)) || "";
      out.push({ courriel: email.toLowerCase(), prenom });
    });
    return out;
  };

  const runImport = () => {
    const parsed = parse(raw);
    if (parsed.length === 0) { flash("Aucun courriel valide détecté."); return; }
    const { ajoutes, maj } = onImport(parsed);
    setRaw("");
    flash(`${ajoutes} ajouté·es · ${maj} mis à jour.`);
  };

  const exportListe = () => {
    const head = ["courriel", "prenom"];
    const lines = [head.join(",")].concat(
      abonnes.map((c) => [c.courriel, (c.nom !== c.courriel ? c.nom : "")].map((v) => '"' + String(v || "").replace(/"/g, '""') + '"').join(","))
    );
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "soha_liste_infolettre_" + todayISO().replace(/-/g, "") + ".csv"; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="page">
      <header className="page-head"><span className="kicker">Infolettre</span><h1>Ceux qui veulent des nouvelles.</h1></header>

      <div className="info-grid">
        <div className="card">
          <span className="kicker dim">Abonnés actifs</span>
          <div className="stat" style={{ color: "var(--soigner)" }}>{abonnes.length}</div>
          <p className="dim tiny" style={{ marginTop: 4 }}>Consentement daté, source gardée. Chacun peut se désabonner d'un clic.</p>
          {abonnes.length > 0 && <button className="btn" style={{ marginTop: 14 }} onClick={exportListe}>Exporter la liste d'envoi (CSV)</button>}
        </div>

        <div className="card import-card">
          <span className="kicker dim">Importer des abonnés</span>
          <p className="dim tiny" style={{ margin: "6px 0 10px" }}>
            Colle l'export de Cyberimpact (ou une colonne de courriels). Un courriel par ligne, prénom si tu l'as.
            Les contacts existants sont reconnus, les nouveaux sont créés en apprenant·e.
          </p>
          <textarea className="import-box" rows={5} placeholder={"prenom, courriel\nÉloïse, eloise@exemple.ca\njean@exemple.ca"} value={raw} onChange={(e) => setRaw(e.target.value)} />
          <button className="btn btn-primary" style={{ marginTop: 10 }} onClick={runImport}>Importer</button>
        </div>
      </div>

      {abonnes.length === 0 ? (
        <Empty>Aucun abonné pour l'instant. Mets le formulaire en ligne, laisse Cyberimpact recueillir, puis rapatrie la liste ici.</Empty>
      ) : (
        <table className="tbl full">
          <thead><tr><th>Nom</th><th>Courriel</th><th>Consentement</th><th>Source</th><th></th></tr></thead>
          <tbody>
            {abonnes.map((c) => (
              <tr key={c.id}>
                <td className="strong"><button className="linkish" onClick={() => openContact(c.id)}>{c.nom}</button></td>
                <td className="dim">{c.courriel}</td>
                <td className="mono tiny">{fmtDate(c.infolettre.consentement)}</td>
                <td className="tiny">{c.infolettre.source || "—"}</td>
                <td><button className="x small" title="Désabonner" onClick={() => { if (confirm("Désabonner " + c.nom + " ?")) { setAbo(c.id, false); flash("Désabonné·e."); } }}>×</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

/* ============================== Répertoire ============================== */
function Repertoire({ data, openId, setOpen, onNew, onEdit, onDelete, onInteraction, setAbo, reservations }) {
  const [q, setQ] = useState("");
  const [filtType, setFiltType] = useState("");
  const list = useMemo(() => data.contacts
    .filter((c) => (filtType ? c.type === filtType : true))
    .filter((c) => (q ? (c.nom + " " + (c.courriel || "") + " " + (c.note || "")).toLowerCase().includes(q.toLowerCase()) : true))
    .sort((a, b) => a.nom.localeCompare(b.nom)), [data.contacts, q, filtType]);
  const open = openId ? data.contacts.find((c) => c.id === openId) : null;

  return (
    <div className="page">
      <header className="page-head row">
        <div><span className="kicker">Répertoire</span><h1>Qui gravite autour du 961.</h1></div>
        <button className="btn btn-primary" onClick={onNew}>+ Nouveau contact</button>
      </header>
      <div className="toolbar">
        <input className="search" placeholder="Chercher un nom, un courriel…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="filters">
          <button className={"pill" + (filtType === "" ? " on" : "")} onClick={() => setFiltType("")}>Tous</button>
          {TYPES.map((t) => (<button key={t.id} className={"pill" + (filtType === t.id ? " on" : "")} onClick={() => setFiltType(t.id)}>{t.label}</button>))}
        </div>
      </div>
      {list.length === 0 ? <Empty>Aucun contact ici. Ajoute la première personne — un·e artisan·e, un·e apprenant·e, un prospect.</Empty> : (
        <table className="tbl full">
          <thead><tr><th>Nom</th><th>Type</th><th>École</th><th>Statut</th><th>Infolettre</th></tr></thead>
          <tbody>
            {list.map((c) => {
              const e = ecole(c.ecole);
              return (
                <tr key={c.id} className="clickrow" onClick={() => setOpen(c.id)}>
                  <td className="strong">{c.nom}</td>
                  <td><span className="chip">{typeLabel(c.type)}</span></td>
                  <td>{e ? <span className="ecole-tag"><span className="dot" style={{ background: e.color }} />{e.label}</span> : <span className="dim">—</span>}</td>
                  <td className="mono tiny">{c.statut}</td>
                  <td>{isAbonne(c) ? <span className="ecole-tag"><span className="dot" style={{ background: "var(--soigner)" }} />abonné·e</span> : <span className="dim tiny">—</span>}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
      {open && (
        <ContactDrawer c={open} reservations={reservations.filter((r) => r.contactId === open.id)}
          onClose={() => setOpen(null)} onEdit={() => onEdit(open)} onDelete={() => onDelete(open.id)}
          onInteraction={(t) => onInteraction(open.id, t)} setAbo={setAbo} />
      )}
    </div>
  );
}

function ContactDrawer({ c, reservations, onClose, onEdit, onDelete, onInteraction, setAbo }) {
  const [note, setNote] = useState("");
  const e = ecole(c.ecole);
  const abo = isAbonne(c);
  return (
    <>
      <div className="scrim" onClick={onClose} />
      <aside className="drawer">
        <div className="drawer-head">
          <div><span className="chip">{typeLabel(c.type)}</span>{e && <span className="ecole-tag inline"><span className="dot" style={{ background: e.color }} />{e.label}</span>}</div>
          <button className="x" onClick={onClose}>×</button>
        </div>
        <h2 className="drawer-name">{c.nom}</h2>
        <div className="mono tiny dim">{c.statut} · ajouté le {fmtDate(c.ajoute)}</div>

        <dl className="deflist">
          {c.courriel && <><dt>Courriel</dt><dd><a href={"mailto:" + c.courriel}>{c.courriel}</a></dd></>}
          {c.telephone && <><dt>Téléphone</dt><dd>{c.telephone}</dd></>}
          {c.note && <><dt>Note</dt><dd>{c.note}</dd></>}
        </dl>

        <div className="drawer-block">
          <span className="kicker dim">Infolettre</span>
          <div className="abo-row">
            <div>
              {abo ? <span className="ecole-tag"><span className="dot" style={{ background: "var(--soigner)" }} />abonné·e</span> : <span className="dim">non abonné·e</span>}
              {abo && c.infolettre.consentement && <div className="mono tiny dim" style={{ marginTop: 3 }}>consentement {fmtDate(c.infolettre.consentement)} · {c.infolettre.source || "—"}</div>}
            </div>
            <button className="btn btn-ghost" disabled={!c.courriel} onClick={() => setAbo(c.id, !abo)}>{abo ? "Désabonner" : "Abonner"}</button>
          </div>
          {!c.courriel && <p className="dim tiny">Ajoute un courriel pour pouvoir l'abonner.</p>}
        </div>

        {reservations.length > 0 && (
          <div className="drawer-block">
            <span className="kicker dim">Réservations</span>
            <ul className="mini-list">
              {reservations.sort((a, b) => b.date.localeCompare(a.date)).map((r) => (
                <li key={r.id}><span>{fmtDate(r.date)} · {r.espace}</span><span className="mono tiny">{money(r.prix)}</span></li>
              ))}
            </ul>
          </div>
        )}

        <div className="drawer-block">
          <span className="kicker dim">Suivi</span>
          <div className="addnote">
            <input placeholder="Noter un échange, un rappel…" value={note} onChange={(ev) => setNote(ev.target.value)}
              onKeyDown={(ev) => { if (ev.key === "Enter" && note.trim()) { onInteraction(note.trim()); setNote(""); } }} />
            <button className="btn btn-ghost" onClick={() => { if (note.trim()) { onInteraction(note.trim()); setNote(""); } }}>Ajouter</button>
          </div>
          {(c.interactions || []).length === 0 ? <p className="dim tiny">Aucune note pour l'instant.</p> : (
            <ul className="timeline">
              {c.interactions.map((it) => (<li key={it.id}><span className="mono tiny dim">{fmtDate(it.date)}</span><span>{it.texte}</span></li>))}
            </ul>
          )}
        </div>

        <div className="drawer-actions">
          <button className="btn" onClick={onEdit}>Modifier</button>
          <button className="btn btn-danger" onClick={() => { if (confirm("Retirer " + c.nom + " ?")) onDelete(); }}>Retirer</button>
        </div>
      </aside>
    </>
  );
}

/* =============================== Location =============================== */
function Location({ data, contactById, onNew, onEdit, onDelete }) {
  const [filt, setFilt] = useState("avenir");
  const rows = useMemo(() => {
    let r = data.reservations.slice();
    if (filt === "avenir") r = r.filter((x) => x.date >= todayISO());
    return r.sort((a, b) => a.date.localeCompare(b.date));
  }, [data.reservations, filt]);
  const totalConfirme = data.reservations.filter((r) => r.paiement !== "devis").reduce((s, r) => s + (Number(r.prix) || 0), 0);
  return (
    <div className="page">
      <header className="page-head row">
        <div><span className="kicker">Location · salles + studio</span><h1>Le revenu qui revient chaque semaine.</h1></div>
        <button className="btn btn-primary" onClick={onNew}>+ Réservation</button>
      </header>
      <div className="banner"><span className="mono tiny dim">Total confirmé + encaissé</span><span className="banner-num">{money(totalConfirme)}</span></div>
      <div className="filters">
        <button className={"pill" + (filt === "avenir" ? " on" : "")} onClick={() => setFilt("avenir")}>À venir</button>
        <button className={"pill" + (filt === "tout" ? " on" : "")} onClick={() => setFilt("tout")}>Tout</button>
      </div>
      {rows.length === 0 ? <Empty>Aucune réservation. Chaque case remplie, c'est du récurrent. Commence par une location régulière.</Empty> : (
        <table className="tbl full">
          <thead><tr><th>Date</th><th>Espace</th><th>Créneau</th><th>Qui</th><th>Récurrence</th><th>Prix</th><th>Statut</th><th></th></tr></thead>
          <tbody>
            {rows.map((r) => {
              const c = contactById(r.contactId); const p = paie(r.paiement);
              return (
                <tr key={r.id} className="clickrow" onClick={() => onEdit(r)}>
                  <td className="mono nowrap">{fmtDate(r.date)}</td><td className="strong">{r.espace}</td>
                  <td className="mono tiny">{r.debut || "—"}{r.fin ? "–" + r.fin : ""}</td>
                  <td className="dim">{c ? c.nom : "—"}</td><td className="tiny">{r.recurrence}</td>
                  <td className="mono nowrap">{money(r.prix)}</td><td><Badge color={p.color} label={p.label} /></td>
                  <td onClick={(e) => e.stopPropagation()}><button className="x small" onClick={() => { if (confirm("Retirer cette réservation ?")) onDelete(r.id); }}>×</button></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      )}
    </div>
  );
}

/* =============================== Ateliers =============================== */
function Ateliers({ data, contactById, onNew, onEdit, onDelete }) {
  const rows = data.ateliers.slice().sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  return (
    <div className="page">
      <header className="page-head row">
        <div><span className="kicker">Ateliers au Centre</span><h1>Ce qui se transmet au 961.</h1></div>
        <button className="btn btn-primary" onClick={onNew}>+ Atelier</button>
      </header>
      {rows.length === 0 ? <Empty>Aucun atelier. Programme le premier — une date, un·e artisan·e, une école.</Empty> : (
        <div className="cards-grid">
          {rows.map((a) => {
            const e = ecole(a.ecole); const art = contactById(a.artisanId);
            const taux = a.capacite ? Math.round((Number(a.inscrits) || 0) / a.capacite * 100) : 0;
            return (
              <div key={a.id} className="atelier-card" onClick={() => onEdit(a)}>
                <div className="ac-accent" style={{ background: e ? e.color : "var(--line)" }} />
                <div className="ac-body">
                  <div className="ac-meta mono tiny">{fmtDate(a.date)}</div>
                  <h3>{a.titre}</h3>
                  <div className="ac-art dim">{art ? art.nom : "artisan·e à confirmer"}</div>
                  {e && <div className="ecole-tag"><span className="dot" style={{ background: e.color }} />{e.label}</div>}
                  <div className="ac-foot">
                    <span className="mono tiny">{money(a.prix)}</span>
                    {a.capacite ? <span className="mono tiny dim">{a.inscrits || 0}/{a.capacite} · {taux}%</span> : null}
                  </div>
                  {a.capacite ? <div className="bar"><span style={{ width: Math.min(taux, 100) + "%", background: e ? e.color : "var(--cultiver)" }} /></div> : null}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ============================== Formulaires ============================== */
function Modal({ title, children, onClose }) {
  return (
    <><div className="scrim" onClick={onClose} />
      <div className="modal">
        <div className="modal-head"><h2>{title}</h2><button className="x" onClick={onClose}>×</button></div>
        <div className="modal-body">{children}</div>
      </div></>
  );
}
function Field({ label, children }) { return <label className="field"><span>{label}</span>{children}</label>; }

function ContactForm({ modal, onSave, onClose }) {
  const base = modal.entity ? normalizeC(modal.entity) : {
    id: uid(), nom: "", type: "apprenante", ecole: "", courriel: "", telephone: "",
    statut: "Nouveau", etiquettes: [], note: "", interactions: [], ajoute: todayISO(), infolettre: emptyInfo(),
  };
  function normalizeC(c) { return { ...c, infolettre: { ...emptyInfo(), ...(c.infolettre || {}) } }; }
  const [f, setF] = useState(base);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const setAbonne = (on) => setF((s) => {
    const info = { ...emptyInfo(), ...s.infolettre };
    if (on) { info.abonne = true; info.desabonne = false; if (!info.consentement) info.consentement = todayISO(); if (!info.source) info.source = "manuel"; }
    else { info.abonne = false; info.desabonne = true; }
    return { ...s, infolettre: info };
  });
  const valid = f.nom.trim().length > 0;
  const abo = f.infolettre && f.infolettre.abonne && !f.infolettre.desabonne;
  return (
    <Modal title={modal.mode === "add" ? "Nouveau contact" : "Modifier le contact"} onClose={onClose}>
      <Field label="Nom"><input value={f.nom} onChange={(e) => set("nom", e.target.value)} autoFocus /></Field>
      <div className="field-row">
        <Field label="Type"><select value={f.type} onChange={(e) => set("type", e.target.value)}>{TYPES.map((t) => <option key={t.id} value={t.id}>{t.label}</option>)}</select></Field>
        <Field label="École (si pertinent)"><select value={f.ecole} onChange={(e) => set("ecole", e.target.value)}><option value="">—</option>{ECOLES.map((e) => <option key={e.id} value={e.id}>{e.label}</option>)}</select></Field>
      </div>
      <div className="field-row">
        <Field label="Courriel"><input type="email" value={f.courriel} onChange={(e) => set("courriel", e.target.value)} /></Field>
        <Field label="Téléphone"><input value={f.telephone} onChange={(e) => set("telephone", e.target.value)} /></Field>
      </div>
      <Field label="Statut"><select value={f.statut} onChange={(e) => set("statut", e.target.value)}>{STATUTS.map((s) => <option key={s} value={s}>{s}</option>)}</select></Field>
      <Field label="Note"><textarea rows={2} value={f.note} onChange={(e) => set("note", e.target.value)} /></Field>
      <label className="consent-inline">
        <input type="checkbox" checked={abo} disabled={!f.courriel} onChange={(e) => setAbonne(e.target.checked)} />
        <span>Abonné·e à l'infolettre {f.courriel ? "" : "(ajoute un courriel d'abord)"}{abo && f.infolettre.consentement ? " · depuis le " + fmtDate(f.infolettre.consentement) : ""}</span>
      </label>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onClose}>Annuler</button>
        <button className="btn btn-primary" disabled={!valid} onClick={() => onSave(f)}>Enregistrer</button>
      </div>
    </Modal>
  );
}

function ReservationForm({ modal, contacts, onSave, onClose }) {
  const base = modal.entity || { id: uid(), contactId: "", espace: ESPACES[0], date: todayISO(), debut: "", fin: "", prix: "", recurrence: "Ponctuel", paiement: "devis", note: "" };
  const [f, setF] = useState(base);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  return (
    <Modal title={modal.mode === "add" ? "Nouvelle réservation" : "Modifier la réservation"} onClose={onClose}>
      <div className="field-row">
        <Field label="Espace"><input list="espaces" value={f.espace} onChange={(e) => set("espace", e.target.value)} /><datalist id="espaces">{ESPACES.map((s) => <option key={s} value={s} />)}</datalist></Field>
        <Field label="Date"><input type="date" value={f.date} onChange={(e) => set("date", e.target.value)} /></Field>
      </div>
      <div className="field-row">
        <Field label="Début"><input type="time" value={f.debut} onChange={(e) => set("debut", e.target.value)} /></Field>
        <Field label="Fin"><input type="time" value={f.fin} onChange={(e) => set("fin", e.target.value)} /></Field>
      </div>
      <Field label="Qui loue"><select value={f.contactId} onChange={(e) => set("contactId", e.target.value)}><option value="">— (à préciser)</option>{contacts.slice().sort((a, b) => a.nom.localeCompare(b.nom)).map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}</select></Field>
      <div className="field-row">
        <Field label="Prix (CAD)"><input type="number" min="0" value={f.prix} onChange={(e) => set("prix", e.target.value)} /></Field>
        <Field label="Récurrence"><select value={f.recurrence} onChange={(e) => set("recurrence", e.target.value)}>{RECURRENCES.map((r) => <option key={r} value={r}>{r}</option>)}</select></Field>
      </div>
      <Field label="Statut de paiement">
        <div className="seg">
          {PAIEMENTS.map((p) => (
            <button key={p.id} type="button" className={"seg-btn" + (f.paiement === p.id ? " on" : "")}
              style={f.paiement === p.id ? { borderColor: p.color, color: p.color } : {}} onClick={() => set("paiement", p.id)}>{p.label}</button>
          ))}
        </div>
      </Field>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onClose}>Annuler</button>
        <button className="btn btn-primary" onClick={() => onSave(f)}>Enregistrer</button>
      </div>
    </Modal>
  );
}

function AtelierForm({ modal, contacts, onSave, onClose }) {
  const artisanes = contacts.filter((c) => c.type === "artisane");
  const base = modal.entity || { id: uid(), titre: "", artisanId: "", ecole: "soigner", date: todayISO(), capacite: "", inscrits: "", prix: "", note: "" };
  const [f, setF] = useState(base);
  const set = (k, v) => setF((s) => ({ ...s, [k]: v }));
  const valid = f.titre.trim().length > 0;
  return (
    <Modal title={modal.mode === "add" ? "Nouvel atelier" : "Modifier l'atelier"} onClose={onClose}>
      <Field label="Titre"><input value={f.titre} onChange={(e) => set("titre", e.target.value)} autoFocus /></Field>
      <div className="field-row">
        <Field label="Artisan·e"><select value={f.artisanId} onChange={(e) => set("artisanId", e.target.value)}><option value="">— à confirmer</option>{artisanes.map((c) => <option key={c.id} value={c.id}>{c.nom}</option>)}</select></Field>
        <Field label="École"><select value={f.ecole} onChange={(e) => set("ecole", e.target.value)}>{ECOLES.map((e) => <option key={e.id} value={e.id}>{e.label}</option>)}</select></Field>
      </div>
      <div className="field-row">
        <Field label="Date"><input type="date" value={f.date} onChange={(e) => set("date", e.target.value)} /></Field>
        <Field label="Prix (CAD)"><input type="number" min="0" value={f.prix} onChange={(e) => set("prix", e.target.value)} /></Field>
      </div>
      <div className="field-row">
        <Field label="Capacité"><input type="number" min="0" value={f.capacite} onChange={(e) => set("capacite", e.target.value)} /></Field>
        <Field label="Inscrits"><input type="number" min="0" value={f.inscrits} onChange={(e) => set("inscrits", e.target.value)} /></Field>
      </div>
      <div className="modal-actions">
        <button className="btn btn-ghost" onClick={onClose}>Annuler</button>
        <button className="btn btn-primary" disabled={!valid} onClick={() => onSave(f)}>Enregistrer</button>
      </div>
    </Modal>
  );
}

/* ============================== Utilitaires ============================== */
function Badge({ color, label }) { return <span className="badge"><span className="dot" style={{ background: color }} />{label}</span>; }
function Empty({ children, small }) { return <div className={"empty" + (small ? " small" : "")}>{children}</div>; }
function Loading() { return <div className="loading"><Style /><span className="mono">Chargement…</span></div>; }

function ExportMenu({ data, onReset }) {
  const download = (name, text, mime) => {
    const blob = new Blob([text], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = name; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  const exportJSON = () => download("soha_crm_" + todayISO().replace(/-/g, "") + ".json", JSON.stringify(data, null, 2), "application/json");
  const exportCSV = () => {
    const head = ["nom", "type", "ecole", "statut", "courriel", "telephone", "note"];
    const lines = [head.join(",")].concat(data.contacts.map((c) => head.map((k) => '"' + String(c[k] || "").replace(/"/g, '""') + '"').join(",")));
    download("soha_contacts_" + todayISO().replace(/-/g, "") + ".csv", lines.join("\n"), "text/csv");
  };
  return (
    <div className="export">
      <button className="btn btn-mini" onClick={exportCSV}>Exporter contacts (CSV)</button>
      <button className="btn btn-mini" onClick={exportJSON}>Sauvegarde (JSON)</button>
      <button className="btn btn-mini danger" onClick={() => { if (confirm("Tout réinitialiser ? Les données actuelles seront perdues.")) onReset(); }}>Réinitialiser</button>
    </div>
  );
}

/* ================================ Style ================================ */
function Style() {
  return (
    <style>{`
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Schibsted+Grotesk:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap');
.soha, .loading{--encre:#0E1A15; --ivoire:#F4F0E7; --soigner:#19A7DB; --batir:#D29A4E; --cultiver:#5E8C5A; --cramoisi:#AE1E3B;
  --line:rgba(14,26,21,.14); --muted:rgba(14,26,21,.55); --surface:#FBFAF5;
  --serif:'Fraunces',Georgia,serif; --sans:'Schibsted Grotesk',system-ui,sans-serif; --mono:'DM Mono',ui-monospace,monospace;}
.soha *{box-sizing:border-box;}
.soha{display:flex; min-height:100vh; background:var(--ivoire); color:var(--encre); font-family:var(--sans); font-size:15px; line-height:1.5;}
.loading{display:flex;align-items:center;justify-content:center;min-height:100vh;background:var(--ivoire);color:var(--muted);}
.rail{width:236px; flex:0 0 236px; background:var(--encre); color:var(--ivoire); display:flex; flex-direction:column; padding:22px 16px; position:sticky; top:0; height:100vh;}
.brand{display:flex; gap:10px; align-items:center; margin-bottom:26px; padding:0 4px;}
.brand-mark{color:var(--soigner); font-size:22px; line-height:1;}
.brand-name{font-family:var(--serif); font-size:18px; font-weight:600;}
.brand-sub{font-family:var(--mono); font-size:11px; letter-spacing:.04em; opacity:.6;}
nav{display:flex; flex-direction:column; gap:2px;}
.navlink{background:none; border:0; text-align:left; color:rgba(244,240,231,.72); font-family:var(--sans); font-size:15px; padding:9px 12px; border-radius:8px; cursor:pointer;}
.navlink:hover{background:rgba(244,240,231,.07); color:var(--ivoire);}
.navlink.on{background:rgba(25,167,219,.16); color:#fff;}
.rail-foot{margin-top:auto; padding-top:16px;}
.export{display:flex; flex-direction:column; gap:6px; margin-bottom:12px;}
.rail-note{font-family:var(--mono); font-size:10.5px; line-height:1.4; color:rgba(244,240,231,.4);}
.main{flex:1; min-width:0; overflow:auto; height:100vh;}
.page{max-width:1120px; margin:0 auto; padding:40px 44px 80px;}
.page-head{margin-bottom:26px;}
.page-head.row{display:flex; justify-content:space-between; align-items:flex-end; gap:16px;}
.page-head h1{font-family:var(--serif); font-weight:600; font-size:clamp(26px,3.4vw,40px); line-height:1.05; margin:4px 0 0; letter-spacing:-.01em;}
.kicker{font-family:var(--mono); font-size:11px; letter-spacing:.12em; text-transform:uppercase; color:var(--encre);}
.kicker.dim{color:var(--muted);}
.grid{display:grid; grid-template-columns:1.4fr 1fr 1fr; gap:16px; margin-bottom:16px;}
.two-col{display:grid; grid-template-columns:1.4fr 1fr; gap:16px;}
.info-grid{display:grid; grid-template-columns:1fr 1.4fr; gap:16px; margin-bottom:20px;}
.card{background:var(--surface); border:1px solid var(--line); border-radius:12px; padding:20px 22px;}
.card-head{margin-bottom:12px;}
.hero-card{background:var(--encre); color:var(--ivoire); border:0;}
.hero-num{font-family:var(--serif); font-size:clamp(40px,6vw,64px); font-weight:600; line-height:1; margin:10px 0 6px;}
.hero-sub{font-size:14px; color:rgba(244,240,231,.75);}
.hero-sub strong{color:var(--soigner); font-weight:600;}
.hero-tag{margin-top:16px; font-family:var(--mono); font-size:11px; letter-spacing:.04em; color:rgba(244,240,231,.5);}
.stat{font-family:var(--serif); font-size:44px; font-weight:600; line-height:1; margin:8px 0 14px;}
.type-list{display:flex; flex-direction:column; gap:7px;}
.type-row{display:flex; justify-content:space-between; font-size:13.5px; padding-bottom:6px; border-bottom:1px solid var(--line);}
.type-row:last-child{border:0; padding:0;}
.mini-list{list-style:none; margin:8px 0 0; padding:0; display:flex; flex-direction:column; gap:8px;}
.mini-list li{display:flex; justify-content:space-between; align-items:center; gap:10px; font-size:13.5px;}
.linkish{background:none; border:0; color:var(--encre); font-family:var(--sans); font-size:13.5px; cursor:pointer; padding:0; text-align:left; border-bottom:1px solid transparent;}
.linkish:hover{border-color:var(--encre);}
.atelier-mini{list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:12px;}
.am-top{display:flex; align-items:center; gap:8px;}
.am-title{font-weight:500;}
.am-meta{margin-top:2px;}
.tbl{width:100%; border-collapse:collapse; font-size:13.5px;}
.tbl.full{background:var(--surface); border:1px solid var(--line); border-radius:12px; overflow:hidden;}
.tbl th{text-align:left; font-family:var(--mono); font-size:10.5px; letter-spacing:.08em; text-transform:uppercase; color:var(--muted); font-weight:400; padding:12px 16px; border-bottom:1px solid var(--line);}
.tbl td{padding:12px 16px; border-bottom:1px solid var(--line); vertical-align:middle;}
.tbl.full tbody tr:last-child td{border-bottom:0;}
.tbl tbody tr:last-child td{border-bottom:0;}
.clickrow{cursor:pointer;}
.clickrow:hover{background:rgba(25,167,219,.05);}
.strong{font-weight:600;} .dim{color:var(--muted);} .tiny{font-size:11.5px;} .mono{font-family:var(--mono);} .nowrap{white-space:nowrap;}
.chip{display:inline-block; font-family:var(--mono); font-size:11px; letter-spacing:.03em; border:1px solid var(--line); border-radius:20px; padding:2px 10px;}
.dot{display:inline-block; width:8px; height:8px; border-radius:50%; flex:0 0 8px;}
.badge{display:inline-flex; align-items:center; gap:6px; font-size:12px; font-family:var(--mono);}
.ecole-tag{display:inline-flex; align-items:center; gap:6px; font-size:12px;}
.ecole-tag.inline{margin-left:8px;}
.toolbar{display:flex; justify-content:space-between; align-items:center; gap:16px; margin-bottom:18px; flex-wrap:wrap;}
.search{flex:1; min-width:220px; background:var(--surface); border:1px solid var(--line); border-radius:10px; padding:10px 14px; font-family:var(--sans); font-size:14px; color:var(--encre);}
.search:focus{outline:2px solid var(--soigner); outline-offset:1px;}
.filters{display:flex; gap:6px; flex-wrap:wrap;}
.pill{background:none; border:1px solid var(--line); border-radius:20px; padding:6px 14px; font-family:var(--sans); font-size:13px; cursor:pointer; color:var(--muted);}
.pill:hover{color:var(--encre);}
.pill.on{background:var(--encre); color:var(--ivoire); border-color:var(--encre);}
.banner{display:flex; align-items:baseline; gap:14px; background:var(--encre); color:var(--ivoire); border-radius:12px; padding:16px 22px; margin-bottom:18px;}
.banner-num{font-family:var(--serif); font-size:30px; font-weight:600; color:var(--cultiver);}
.btn{background:var(--surface); border:1px solid var(--line); border-radius:10px; padding:9px 16px; font-family:var(--sans); font-size:14px; cursor:pointer; color:var(--encre);}
.btn:hover{border-color:var(--encre);}
.btn:disabled{opacity:.4; cursor:not-allowed;}
.btn-primary{background:var(--encre); color:var(--ivoire); border-color:var(--encre);}
.btn-primary:hover{background:#16261f;}
.btn-ghost{background:none;}
.btn-danger{color:var(--cramoisi); border-color:rgba(174,30,59,.4);}
.btn-mini{font-size:12px; padding:7px 10px; background:rgba(244,240,231,.06); color:rgba(244,240,231,.85); border-color:rgba(244,240,231,.14);}
.btn-mini:hover{border-color:rgba(244,240,231,.4);}
.btn-mini.danger{color:#e88;}
.empty{background:var(--surface); border:1px dashed var(--line); border-radius:12px; padding:32px; text-align:center; color:var(--muted); font-size:14px; line-height:1.6;}
.empty.small{padding:18px; font-size:13px; border:0; background:none;}
.import-card{display:flex; flex-direction:column;}
.import-box{background:#fff; border:1px solid var(--line); border-radius:10px; padding:10px 12px; font-family:var(--mono); font-size:12.5px; color:var(--encre); resize:vertical; width:100%;}
.import-box:focus{outline:2px solid var(--soigner); outline-offset:1px;}
.abo-row{display:flex; justify-content:space-between; align-items:center; gap:12px; margin-top:8px;}
.scrim{position:fixed; inset:0; background:rgba(14,26,21,.4); z-index:40;}
.drawer{position:fixed; top:0; right:0; width:min(440px,92vw); height:100vh; background:var(--ivoire); z-index:50; padding:24px 26px; overflow:auto; box-shadow:-8px 0 40px rgba(14,26,21,.18);}
.drawer-head{display:flex; justify-content:space-between; align-items:flex-start;}
.drawer-name{font-family:var(--serif); font-size:28px; font-weight:600; margin:12px 0 2px; line-height:1.1;}
.deflist{display:grid; grid-template-columns:auto 1fr; gap:6px 16px; margin:20px 0;}
.deflist dt{font-family:var(--mono); font-size:11px; text-transform:uppercase; letter-spacing:.06em; color:var(--muted); padding-top:2px;}
.deflist dd{margin:0; font-size:14px;}
.deflist a{color:var(--soigner); text-decoration:none;}
.drawer-block{margin-top:22px; padding-top:18px; border-top:1px solid var(--line);}
.addnote{display:flex; gap:8px; margin:10px 0;}
.addnote input{flex:1; background:var(--surface); border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-family:var(--sans); font-size:13.5px;}
.timeline{list-style:none; margin:10px 0 0; padding:0; display:flex; flex-direction:column; gap:10px;}
.timeline li{display:flex; flex-direction:column; gap:2px; font-size:13.5px; padding-left:12px; border-left:2px solid var(--line);}
.drawer-actions{display:flex; gap:10px; margin-top:28px;}
.x{background:none; border:0; font-size:24px; line-height:1; cursor:pointer; color:var(--muted); padding:0 4px;}
.x:hover{color:var(--encre);} .x.small{font-size:18px;}
.modal{position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); z-index:50; width:min(560px,94vw); max-height:90vh; overflow:auto; background:var(--ivoire); border-radius:16px; padding:26px 28px; box-shadow:0 20px 60px rgba(14,26,21,.28);}
.modal-head{display:flex; justify-content:space-between; align-items:center; margin-bottom:18px;}
.modal-head h2{font-family:var(--serif); font-size:22px; font-weight:600; margin:0;}
.field{display:flex; flex-direction:column; gap:5px; margin-bottom:14px;}
.field>span{font-family:var(--mono); font-size:11px; text-transform:uppercase; letter-spacing:.05em; color:var(--muted);}
.field input, .field select, .field textarea{background:var(--surface); border:1px solid var(--line); border-radius:9px; padding:9px 12px; font-family:var(--sans); font-size:14px; color:var(--encre); width:100%;}
.field input:focus, .field select:focus, .field textarea:focus{outline:2px solid var(--soigner); outline-offset:1px;}
.field-row{display:grid; grid-template-columns:1fr 1fr; gap:14px;}
.consent-inline{display:flex; align-items:flex-start; gap:10px; margin:2px 0 18px; font-size:13.5px; line-height:1.4;}
.consent-inline input{width:18px; height:18px; margin-top:1px; flex:0 0 18px; accent-color:var(--soigner);}
.seg{display:flex; gap:8px;}
.seg-btn{flex:1; background:var(--surface); border:1.5px solid var(--line); border-radius:9px; padding:9px; font-family:var(--sans); font-size:13px; cursor:pointer; color:var(--muted);}
.seg-btn.on{font-weight:600;}
.modal-actions{display:flex; justify-content:flex-end; gap:10px; margin-top:8px;}
.cards-grid{display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:16px;}
.atelier-card{display:flex; background:var(--surface); border:1px solid var(--line); border-radius:12px; overflow:hidden; cursor:pointer;}
.atelier-card:hover{border-color:var(--encre);}
.ac-accent{width:5px; flex:0 0 5px;}
.ac-body{padding:16px 18px; flex:1;}
.ac-body h3{font-family:var(--serif); font-size:19px; font-weight:600; margin:4px 0 4px; line-height:1.15;}
.ac-art{font-size:13px; margin-bottom:8px;}
.ac-foot{display:flex; justify-content:space-between; align-items:center; margin-top:12px;}
.bar{height:5px; background:var(--line); border-radius:3px; overflow:hidden; margin-top:8px;}
.bar span{display:block; height:100%;}
.toast{position:fixed; bottom:24px; left:50%; transform:translateX(-50%); z-index:60; background:var(--encre); color:var(--ivoire); padding:11px 20px; border-radius:24px; font-size:13.5px; box-shadow:0 8px 24px rgba(14,26,21,.3);}
@media (max-width:860px){
  .soha{flex-direction:column;}
  .rail{width:100%; flex:none; height:auto; position:static; flex-direction:row; align-items:center; padding:12px 16px; gap:12px; overflow-x:auto;}
  .brand{margin-bottom:0;} nav{flex-direction:row; gap:2px;}
  .rail-foot{margin:0 0 0 auto; padding:0;} .export{flex-direction:row;} .rail-note{display:none;}
  .main{height:auto;} .page{padding:24px 18px 60px;}
  .grid, .two-col, .info-grid{grid-template-columns:1fr;} .field-row{grid-template-columns:1fr;}
}
`}</style>
  );
}
